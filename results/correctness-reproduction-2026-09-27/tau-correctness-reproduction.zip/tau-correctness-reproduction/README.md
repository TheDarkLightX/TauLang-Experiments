# Tau correctness reproduction

This package reproduces small correctness failures in an unmodified Tau build. It contains 27 checks across seven report topics: 17 fail and 10 controls pass on the recorded revision. The `min`/`max` topic has two selectable groups. The counts are checks, not a claim of 17 distinct bugs.

No proposed correction is included or validated. These selected examples do not establish full-suite coverage or performance.

## Quick run

Python 3.9 or later is sufficient for the scripts; they use only the standard library. Supply a Tau executable built from the revision below:

```sh
python3 check_expected.py
python3 -m unittest -v test_check.py
python3 check.py --tau /path/to/tau --output replay.json
```

The first two commands should exit zero. The last should exit **1** on the recorded unmodified build: its summary is `27 checks, 10 passed, 17 failed`. Exit 1 means at least one check failed; inspect the JSON to distinguish a wrong result from a diagnostic, unsupported output format, timeout or process failure. It is not automatically evidence of a new bug.

Run one topic with, for example:

```sh
python3 check.py --tau /path/to/tau --group rational-intervals --output rational-replay.json
```

The output filename must be new. The runner preserves stdout, stderr, exit status, timeouts, commands, flags and the binary SHA-256. Each command runs in a fresh process and temporary working directory with closed input and a 12-second wall-clock limit. The print-and-parse check uses two processes, so a full 27-check run launches 28 processes. It does not rebuild or change Tau.

## Build the recorded revision

Use the dependencies in the pinned [upstream build instructions](https://github.com/IDNI/tau-lang/blob/fd536d56e00f12187cbed123c67a735a6964c660/README.md#compiling-the-source-code). A C++23 compiler is required; the recorded build used Clang 22.1.2, Boost 1.89.0 and cvc5 1.3.1. Ensure the `clang` and `clang++` commands below name the intended compiler. Do not use an older system compiler that lacks the required support.

```sh
git clone https://github.com/IDNI/tau-lang.git tau-source
git -C tau-source checkout --detach fd536d56e00f12187cbed123c67a735a6964c660
git -C tau-source submodule update --init --recursive
git -C tau-source/external/parser rev-parse HEAD
```

The parser revision must be `5b14b6fde86f16dc52c4c0a953a8a1e53c88f95a`. Keep the submodule revision pinned; do not update it to its latest branch.

```sh
cmake -S tau-source -B tau-source/build/release \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++ \
  -DTAU_BUILD_EXECUTABLE=ON -DTAU_DONT_USE_FTXUI=ON \
  -DTAU_LTO=OFF -DTAU_ARTIFACT_PREINST=OFF \
  -DTAU_BAS=tau,qint,qlt,nlang,bv,sbf,hsb
cmake --build tau-source/build/release --target tau --parallel 2
python3 check.py --tau tau-source/build/release/tau --output replay.json
```

Dependencies must be available to CMake as described upstream. The original observations used a retained clean Release build on macOS 26.6.2 arm64, with `-O3 -DNDEBUG`. Its executable SHA-256 was:

```text
1e6336f3f572736b950ee5a91683a92188b33705a6de0f82ba8362d991272112
```

A separately compiled binary can have a different hash. The source revision, configuration, commands and mathematical expectations are the reproduction contract. These setup instructions describe the retained configuration; a second clean build was not performed while assembling this archive.

## Results and expected answers

The full command strings and expectations are in `cases.json`. `observed-stock.json` is the recorded execution of this portable checker.

| Group | Checks | Failures | Independent reason for the expected result |
|---|---:|---:|---|
| `minmax-cast` | 5 | 3 | Set `y=2`; `max(2,1)=2`, unchanged by widening from three to four bits. |
| `minmax-complement` | 5 | 3 | Set `x=1`; the two-bit complement of `min(1,2)` is 2. For the quantified three-bit case choose `b=7` for every `x`. |
| `rational-intervals` | 4 | 3 | `1/3` exceeds `0.3333333333333333` by exactly `1/30000000000000000`. |
| `compound-order` | 2 | 1 | Substituting `x=6` gives the accepted true concrete instance; the existential cannot then be false. |
| `order-endpoints` | 3 | 2 | Each reported formula forces a quantified witness to be strictly less than itself. |
| `nested-conjuncts` | 3 | 2 | For every rational `x,z`, choose `w=x-1` if `z<x`, and `w=x` otherwise. |
| `binder-identity` | 1 | 1 | Each alternative forces `a=c`, while the final constraint requires `c!=a`. |
| `missing-model` | 4 | 2 | `x=0,y=0` satisfies the first constraint; `x=0,y=1` satisfies the distinct-variable constraint. |

### Scope of the independent checks

`check_expected.py` uses exact Python fractions for the interval gap and model witnesses. It checks the small bit-vector witnesses directly. For the constant-free three-variable contradiction, it enumerates all 13 relative order/equality patterns. Any assignment in a total order has one of these patterns, so this enumeration is exhaustive for that formula.

For the nested equivalence, let `A=(x != w) && ((x > w) || (z > x))` and `B=(z < x)`. If `B` is true, `w=x-1` makes `A` true. If `B` is false, `w=x` makes `A` false. This proves `A <-> B` for every rational pair. The script also checks the witness calculation on 289 sample pairs; that finite sample supplements the two-case proof and does not replace it. The exclusive-or formula with reversed quantifiers is the negation, hence false.

The compound-order pair tests substitution consistency. It does not establish a new language specification for compound `qlt` terms. If those terms are unsupported, they need a clear rejection instead of contradictory decided answers for accepted syntax.

The endpoint checks use the unbraced `1`, not the rational-point literal `{1}:qlt`. Their contradictions follow by substituting the existential witness into the universal clause, regardless of how that constant is represented.

### Checker limits

Boolean checks require exactly one `T` or `F` answer and no diagnostic. Model checks require all requested variables and evaluate the actual constraints with exact fractions. The accepted model syntax here is a finite singleton integer or fraction, using the expected `qlt` or `bv[3]` type. A mathematically valid model printed in another format is reported as a failed check for inspection, not proof of a solver error. Duplicate, missing, malformed and wrong-type assignments fail. The printer check feeds the actual normalized formula to a new `sat` process and requires a clean `T`.

`test_check.py` tests these acceptance boundaries, including wrong values, omitted variables, zero denominators, extra output, diagnostics and nonzero process exits. `checker-tests.txt` and `expected-check.json` record those script checks. Checksums in `MANIFEST.sha256` cover every other package file.
