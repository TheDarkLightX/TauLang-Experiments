"""Check that missing answers and invalid models cannot pass the checker."""
import unittest
import check


def row(stdout, **changes):
    result = dict(stdout=stdout, stderr='', returncode=0, timeout=False)
    result.update(changes)
    return result


class CheckerTests(unittest.TestCase):
    def test_boolean_answer(self):
        self.assertTrue(check.verdict(row('%1: T\n\n'), 'T'))
        self.assertFalse(check.verdict(row('%1: F\n'), 'T'))

    def test_diagnostic_is_failure(self):
        self.assertFalse(check.verdict(row('%1: T\n', stderr='error\n'), 'T'))

    def test_missing_or_extra_output_is_failure(self):
        for text in ['', '%1: T\n%2: T\n', '%1: T\nno solution\n']:
            with self.subTest(text=text):
                self.assertFalse(check.verdict(row(text), 'T'))

    def test_failed_process_is_failure(self):
        self.assertFalse(check.verdict(row('%1: T\n', returncode=1), 'T'))
        self.assertFalse(check.verdict(row('%1: T\n', timeout=True), 'T'))

    def test_valid_rational_model(self):
        self.assertTrue(check.model(row('solution: {\nx := {0}:qlt\ny := {1/2}:qlt\n}'), 'model-distinct'))

    def test_missing_variable_is_failure(self):
        self.assertFalse(check.model(row('solution: {\nx := {0}:qlt\n}'), 'model-independent'))

    def test_constraint_violation_is_failure(self):
        for x, y in [(0, 0), (3, 4)]:
            self.assertFalse(check.model(row(f'solution: {{\nx := {{{x}}}:qlt\ny := {{{y}}}:qlt\n}}'), 'model-distinct'))
        self.assertFalse(check.model(row('solution: {\nx := {0}:qlt\ny := {2}:qlt\n}'), 'model-independent'))

    def test_duplicate_variable_is_failure(self):
        self.assertFalse(check.model(row('solution: {\nx := {0}:qlt\nx := {1}:qlt\n}'), 'model-control'))

    def test_wrong_type_is_failure(self):
        self.assertFalse(check.model(row('solution: {\ny := {2}:qlt\n}'), 'model-cast'))

    def test_invalid_fraction_is_failure(self):
        self.assertFalse(check.model(row('solution: {\nx := {1/0}:qlt\n}'), 'model-control'))

    def test_no_solution_is_failure(self):
        self.assertFalse(check.model(row('no solution\n'), 'model-control'))

    def test_valid_cast_model(self):
        self.assertTrue(check.model(row('solution: {\ny := {2}:bv[3]\n}'), 'model-cast'))


if __name__ == '__main__':
    unittest.main()
