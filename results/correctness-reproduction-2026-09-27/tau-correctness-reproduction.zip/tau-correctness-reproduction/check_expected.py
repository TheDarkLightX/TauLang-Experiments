#!/usr/bin/env python3
"""Independent arithmetic and finite order checks; no Tau code is imported."""
from fractions import Fraction
from itertools import product
import json


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


gap = Fraction(1, 3) - Fraction('0.3333333333333333')
require(gap == Fraction(1, 30000000000000000), 'rational gap')
require(max(2, 1) == 2, 'cast witness')
require((min(1, 2) ^ 3) == 2, 'two-bit complement witness')
require(all((min(x, 7) ^ 7) == (x ^ 7) for x in range(8)), 'three-bit witnesses')

# An order-only formula on three variables depends only on their relative
# order and equality. These are all 13 possibilities, not a bounded-domain
# approximation to quantification over the rationals.
orders = set()
for triple in product(range(3), repeat=3):
    ranks = {value: rank for rank, value in enumerate(sorted(set(triple)))}
    orders.add(tuple(ranks[v] for v in triple))
require(len(orders) == 13, 'all three-variable order types')
for a, b, c in orders:
    value = (((a <= c and c <= a and b <= c)
              or (a <= c and c <= a and b < c)) and c != a)
    require(not value, 'order contradiction')

# The README proves this witness rule for every rational x,z. The finite
# sample here is only an additional check of the written calculation.
samples = [Fraction(n, 2) for n in range(-8, 9)]
for x, z in product(samples, repeat=2):
    w = x - 1 if z < x else x
    require((x != w and (x > w or z > x)) == (z < x), 'nested witness')

require(Fraction(0) != 2 and Fraction(0) < 3, 'independent model')
require(Fraction(0) != Fraction(1) and Fraction(0) < 3, 'distinct model')
print(json.dumps(dict(exact_rational_gap=str(gap), three_variable_order_types=len(orders),
                     finite_bitvector_witnesses=True, rational_witness_samples=len(samples)**2,
                     model_witnesses=True), indent=2))
