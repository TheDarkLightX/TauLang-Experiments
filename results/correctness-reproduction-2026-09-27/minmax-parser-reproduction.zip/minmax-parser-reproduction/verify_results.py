#!/usr/bin/env python3
"""Recompute the case corpus and check both recorded runs without invoking Tau."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,shutil,subprocess,tempfile
import check
ROOT=Path(__file__).resolve().parent

def require(ok,message):
    if not ok:raise RuntimeError(message)

with tempfile.TemporaryDirectory(prefix='tau-minmax-expected-') as d:
    tmp=Path(d)
    shutil.copy2(ROOT/'exact_cases.py',tmp/'exact_cases.py')
    subprocess.run(['python3',str(tmp/'exact_cases.py')],check=True,capture_output=True,text=True)
    require((tmp/'exact-cases.json').read_bytes()==(ROOT/'exact-cases.json').read_bytes(),'case generation differs')
cases=json.loads((ROOT/'exact-cases.json').read_text())
byid={c['id']:c for c in cases}
require(len(byid)==2352,'case count')
require(Counter(c['expected'] for c in cases)=={'T':1176,'F':1176},'expected-answer balance')
corpus_hash=hashlib.sha256((ROOT/'exact-cases.json').read_bytes()).hexdigest()
summaries={}
for label,wanted in [('original',400),('candidate',2352)]:
    record=json.loads((ROOT/f'exact-{label}.json').read_text())
    require(record['cases_sha256']==corpus_hash,'corpus hash differs')
    require(len(record['rows'])==len(cases),'result count')
    require({r['id'] for r in record['rows']}==set(byid),'result identities')
    accepted=0
    for row in record['rows']:
        expected=byid[row['id']]['expected']
        good=(row['returncode']==0 and not row['timeout'] and not row['stderr']
              and re.fullmatch(r'%\d+:\s*'+expected+r'\s*',row['stdout']) is not None)
        require(row['passed']==good,'recorded acceptance differs')
        accepted+=good
    require(accepted==wanted,'unexpected acceptance count')
    summaries[label]=dict(checks=len(cases),passed=accepted,failed=len(cases)-accepted)
for label,wanted in [('original',4),('candidate',10)]:
    record=json.loads((ROOT/f'focused-{label}.json').read_text())
    require(record['checks']==10 and record['passed']==wanted,'focused count')
    focused_cases=json.loads((ROOT/'cases.json').read_text())
    require([r['case'] for r in record['results']]==focused_cases,'focused cases differ')
    accepted=0
    for result in record['results']:
        row=result['observation']; expected=result['case']['expected']
        require(row['command']==result['case']['command'],'focused command differs')
        if expected=='roundtrip':
            formula=re.fullmatch(r'%\d+:\s*([^\n]+)\s*',row['stdout'])
            followup=row.get('reparsed')
            good=bool(check.clean(row) and formula and followup
                      and followup['command']=='sat '+formula[1].rstrip('.')+'.'
                      and check.verdict(followup,'T'))
        elif expected in ('T','F'):
            good=check.verdict(row,expected)
        else:
            good=check.model(row,expected)
        require(result['passed']==good,'focused acceptance differs')
        accepted+=good
    require(accepted==wanted,'focused result count')
require(hashlib.sha256((ROOT/'minmax-operands.patch').read_bytes()).hexdigest()==json.loads((ROOT/'frozen-source.json').read_text())['patch_sha256'],'patch hash differs')
tests=json.loads((ROOT/'registered-test-results.json').read_text())
counts={}
for label,wanted_count,wanted_failed in [
        ('original_new_regressions',10,10),('corrected_new_regressions',10,0),
        ('corrected_full_initial',2378,8),('corrected_compiler_rerun',8,0)]:
    rows=tests[label]['tests']; names=[r['name'] for r in rows]
    require(len(names)==len(set(names))==wanted_count,'registered test identities')
    require(all(r['status'] in ('pass','fail') for r in rows),'unexpected registered status')
    failed=sum(r['status']=='fail' for r in rows)
    require(failed==wanted_failed,'registered failure count')
    counts[label]={'tests':wanted_count,'passed':wanted_count-failed,'failed':failed}
initial={r['name']:r['status'] for r in tests['corrected_full_initial']['tests']}
retried={r['name']:r['status'] for r in tests['corrected_compiler_rerun']['tests']}
require(set(retried)=={n for n,s in initial.items() if s=='fail'},'rerun selection differs')
require(all(s=='pass' for s in (initial|retried).values()),'unresolved registered failure')
require({r['name'] for r in tests['original_new_regressions']['tests']}==
        {r['name'] for r in tests['corrected_new_regressions']['tests']},'regression identities differ')
unrelated=json.loads((ROOT/'unrelated-results.json').read_text())
require(len(unrelated['original'])==17 and unrelated['original']==unrelated['corrected'],
        'unrelated observations changed')
print(json.dumps(dict(exact=summaries,focused_original_passed=4,focused_candidate_passed=10,
                     registered=counts,unresolved_registered_failures=0,
                     unrelated_checks_unchanged=17,corpus_recomputed=True,patch_hash_verified=True),indent=2))
