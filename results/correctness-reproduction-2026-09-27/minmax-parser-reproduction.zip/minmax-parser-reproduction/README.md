# Built-in min/max in operand positions

This package contains a small grammar correction for Tau `fd536d56e00f12187cbed123c67a735a6964c660`, with parser `5b14b6fde86f16dc52c4c0a953a8a1e53c88f95a`. It recognizes built-in `min` and `max` under casts, under complement, and on either side of adjacent expressions. The patch also registers ten command-level regression tests.

The original build can interpret those built-ins as unresolved function references in these positions. A valid expression can consequently produce the wrong `sat`, `valid` or `solve` result; printing a normalized expression can also produce a form that parses differently.

## Focused results

| Check set | Original | Grammar correction |
|---|---:|---:|
| Ten focused checks, including a model and a print-and-parse check | 4 pass, 6 fail | 10 pass |
| 2,352 exact ground-expression checks | 400 pass, 1,952 fail | 2,352 pass |
| Ten added command-level regressions | 0 pass, 10 fail | 10 pass |

The 1,952 ground-expression failures are **340 diagnostics and 1,612 expressions left undecided**, not 1,952 wrong Boolean answers. This set uses `normalize`; the focused set separately demonstrates the wrong decided answers through `sat`, `valid` and `solve`. A diagnostic or undecided expression fails these ground-expression checks because the complete constant expression has a computable result.

The exact set covers both operations, all pairs of one-, two- and three-bit values, seven expression positions, and both true and false equality checks. Seven positions are: a wider cast, a narrower cast, complement, adjacency to a constant, adjacency to another built-in, the corresponding space-separated expression, and a nested built-in under complement. Expected values come directly from integer minimum/maximum, masking and bitwise operations in `exact_cases.py`. This is exhaustive for that finite collection of expression forms, not for Tau's complete language.

The focused checker checks the actual returned model and feeds the actual normalized output to a new process. Seventeen unrelated checks from a separate correctness set produced exactly the same observations before and after this patch; this correction does not claim to repair their `qint` or `qlt` failures.

All measurements here are correctness checks. Process durations in the records are diagnostic only; no speedup is claimed.

## Registered Release tests

The complete configured Release suite ran once: **2,370 passed and 8 failed out of 2,378 registered tests**. All eight failures involved compiling generated C++ programs with the system compiler, which could not find standard headers. With GCC 15.2.0 selected for `g++` and Clang 22.1.2 selected for generated CMake builds, **all eight passed on a targeted rerun**. Source and Tau binary hashes were unchanged. There are no unresolved failures from this run; this is not a claim that the initial run was green.

`registered-test-results.json` records every test's name and result, the initial failed-test output, the ten new regressions' output, and the compiler rerun. The new regressions failed against the original executable using the same commands and CTest acceptance rules. Private machine and temporary paths in this file are replaced by descriptive placeholders. `build-verification.json` records source, patch and binary hashes.

This covers the configured default Release suite. The preset's default excluded suites and optional code-generation tests gated by environment variables remain excluded; other type packs, sanitizers and other platforms were not added. A passing registered wrapper does not imply that an opt-in test body ran.

## Recheck the stored evidence

Python 3.9 or later is sufficient; the scripts use only its standard library:

```sh
python3 verify_results.py
```

This regenerates the arithmetic cases in a temporary directory, verifies the frozen corpus, checks every recorded arithmetic and focused answer, checks the registered-test counts and rerun selection, and checks the patch hash.

## Build and run

Use the pinned [upstream dependencies and build instructions](https://github.com/IDNI/tau-lang/blob/fd536d56e00f12187cbed123c67a735a6964c660/README.md#compiling-the-source-code). Choose a C++23 compiler supported by that revision. The recorded build uses Clang 22.1.2, Boost 1.89.0, cvc5 1.3.1 and macOS 26.6.2 arm64. The type pack is the revision's default: `tau,qint,qlt,nlang,bv,sbf,hsb`.

From this package directory, obtain two clean copies:

```sh
TAU_REPRO_PACKAGE="$PWD"
git clone https://github.com/IDNI/tau-lang.git tau-original
git -C tau-original checkout --detach fd536d56e00f12187cbed123c67a735a6964c660
git -C tau-original submodule update --init --recursive
git clone https://github.com/IDNI/tau-lang.git tau-corrected
git -C tau-corrected checkout --detach fd536d56e00f12187cbed123c67a735a6964c660
git -C tau-corrected submodule update --init --recursive
git -C tau-corrected apply --check "$TAU_REPRO_PACKAGE/minmax-operands.patch"
git -C tau-corrected apply "$TAU_REPRO_PACKAGE/minmax-operands.patch"
```

For each copy, verify that `git -C external/parser rev-parse HEAD` prints `5b14b6fde86f16dc52c4c0a953a8a1e53c88f95a` when run from that copy. The generated parser is a build product; it should be regenerated by the build, not edited by hand.

Build from each source directory, passing the same compiler and dependency settings to both. For a system where `clang` and `clang++` name a supported compiler:

```sh
./dev preset release-tests --target tau \
  -DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++ \
  -DTAU_BUILD_JOBS=4 -DTAU_LTO=OFF -DTAU_ARTIFACT_PREINST=OFF \
  -DTAU_DONT_USE_FTXUI=ON
```

On the recorded Homebrew setup, the full invocation was instead:

```sh
TAU_REPRO_LLVM="$(brew --prefix llvm)"
TAU_REPRO_ICU="$(brew --prefix icu4c)"
./dev preset release-tests --target tau \
  -DCMAKE_C_COMPILER="$TAU_REPRO_LLVM/bin/clang" \
  -DCMAKE_CXX_COMPILER="$TAU_REPRO_LLVM/bin/clang++" \
  -DCVC5_DIR="$HOME/.tau/cvc5/dist/lib/cmake/cvc5" \
  -DCMAKE_EXE_LINKER_FLAGS="-L$TAU_REPRO_ICU/lib" \
  -DTAU_BUILD_JOBS=4 -DTAU_LTO=OFF -DTAU_ARTIFACT_PREINST=OFF \
  -DTAU_DONT_USE_FTXUI=ON
```

The ICU search directory is needed by this installation's Boost.Regex library. Keep the complete compiler and dependency options when invoking the preset again: `--keep-cache` alone does not prevent preset values from changing the compiler. These are local setup requirements, not changes to Tau's source.

Back in the package directory, run:

```sh
python3 check.py --tau tau-original/build/release/tau --output focused-original-replay.json
python3 check.py --tau tau-corrected/build/release/tau --output focused-corrected-replay.json
python3 run_exact.py --tau tau-original/build/release/tau --output exact-original-replay.json
python3 run_exact.py --tau tau-corrected/build/release/tau --output exact-corrected-replay.json
```

Both original-build commands are expected to exit 1 because their checks fail. Both corrected-build commands should exit zero. Output names must be new. Every Tau call starts a new process, records stdout and stderr, and has a 12-second limit. There are 11 processes for the ten focused checks because the print-and-parse check invokes Tau twice. A valid model printed in an unrecognized format fails for inspection rather than being accepted without validation.

To run the full registered Release suite, invoke the same build command in `tau-corrected` **without `--target tau`**, retaining the complete compiler and dependency options, then run:

```sh
ctest --preset release-tests --parallel 8 --timeout 180 --output-on-failure
```

The command-level regressions can also be run alone with `ctest --preset release-tests -R '^test_repl-minmax_operands-' --output-on-failure`.

To run those same ten registered commands against either executable without modifying its source tree, use the extracted CTest definitions:

```sh
python3 replay_regressions.py --binary tau-original/build/release/tau --output-dir regressions-original
python3 replay_regressions.py --binary tau-corrected/build/release/tau --output-dir regressions-corrected
```

The original is expected to fail all ten; the corrected executable should pass all ten. These use the upstream command-test defaults and CTest rules. The focused and exact Python checkers above use the explicitly listed flags and stricter output checks.

Some code-generation tests invoke `g++` or `clang++` themselves. Configure the compilers for those child processes as well as for the main build. The recorded macOS rerun used an isolated directory containing a `g++` symlink to Homebrew GCC 15.2.0, with Homebrew LLVM 22.1.2 on `PATH`:

```sh
mkdir -p "$TAU_REPRO_PACKAGE/runtime-compilers"
ln -s "$(brew --prefix gcc)/bin/g++-15" "$TAU_REPRO_PACKAGE/runtime-compilers/g++"
PATH="$TAU_REPRO_PACKAGE/runtime-compilers:$TAU_REPRO_LLVM/bin:$PATH" \
  TAU_CXX="$TAU_REPRO_LLVM/bin/clang++" \
  LDFLAGS="-L$TAU_REPRO_ICU/lib" \
  ctest --preset release-tests --rerun-failed --parallel 4 --timeout 180 --output-on-failure
```

The recorded rerun selected the eight initial failures explicitly; `--rerun-failed` is equivalent immediately after the full run, before running any other tests. These compiler selections affect only the invoked command. They do not change the installed system compiler or Tau's source.

## Patch limits

This patch changes the grammar's operand alternatives and adds tests. It does not change the general handling of unresolved functions, the arithmetic quantifier-elimination rule or any solver algorithm. It does not establish full language correctness, performance neutrality, or behavior on another operating system. The historical originals and their recorded failures are retained alongside the candidate results.
