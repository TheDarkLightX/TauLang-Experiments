#!/usr/bin/env python3
"""Replay selected registered command tests against an explicit Tau binary."""
from pathlib import Path
import argparse,json,shlex,subprocess
p=argparse.ArgumentParser()
p.add_argument('--binary',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True)
p.add_argument('--names-file',type=Path)
a=p.parse_args();root=Path(__file__).resolve().parent
if a.output_dir.exists():raise SystemExit('Output directory exists')
a.output_dir.mkdir(parents=True)
d={'tests':json.loads((root/'new-regression-definitions.json').read_text())}
names=set(json.loads(a.names_file.read_text())) if a.names_file else None
selected=[t for t in d['tests'] if t['name'] in names] if names is not None else [t for t in d['tests'] if t['name'].startswith('test_repl-minmax_operands-')]
original='TAU_BINARY'
binary=shlex.quote(str(a.binary.resolve(strict=True)))
def quote(value):
    if ']==]' in value:raise RuntimeError('Unexpected CMake delimiter')
    return '[==['+value+']==]'
lines=[]
for t in selected:
    command=t.get('command',[])
    if not command or not any(original in s for s in command):raise RuntimeError('Test is not a Tau command: '+t['name'])
    command=[s.replace(original,binary) for s in command]
    lines.append('add_test('+quote(t['name'])+' '+' '.join(quote(s) for s in command)+')')
    properties={prop['name']:prop['value'] for prop in t['properties']}
    for key in ['PASS_REGULAR_EXPRESSION','FAIL_REGULAR_EXPRESSION','WILL_FAIL','TIMEOUT']:
        if key not in properties:continue
        value=properties[key]
        if isinstance(value,list):value=';'.join(str(v) for v in value)
        if isinstance(value,bool):value='TRUE' if value else 'FALSE'
        lines.append('set_tests_properties('+quote(t['name'])+' PROPERTIES '+key+' '+quote(str(value))+')')
(a.output_dir/'CTestTestfile.cmake').write_text('\n'.join(lines)+'\n')
args=['ctest','--test-dir',str(a.output_dir.resolve()),'--output-on-failure','--timeout','180','--parallel','4','--output-junit',str((a.output_dir/'results.xml').resolve())]
r=subprocess.run(args,capture_output=True,text=True)
(a.output_dir/'ctest.log').write_text(r.stdout+r.stderr)
print(r.stdout[-3500:]);raise SystemExit(r.returncode)
