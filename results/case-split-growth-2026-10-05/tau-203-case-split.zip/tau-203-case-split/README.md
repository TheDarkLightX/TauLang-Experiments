# Case-split growth budget for Tau issue 203

This is an exploratory implementation offered as a possible direction for
discussion, not an official Tau patch or a complete fix for issue 203.
It tests a proposed bitvector case-split growth budget against Tau
`92b760179ac6412270e54369a2d225dd226fdf18`, with parser
`7d24705ac11863fa48261208134abc68e6c9cc1d`.
The rule generator is adapted from [Andrei's report and reproduction](https://github.com/IDNI/tau-lang/issues/203).

The proposed change is `patches/case-split-growth.patch`. The other three
patches address macOS build problems and were applied equally to both builds.
They are separate from the case-split proposal.

## Build

Use the pinned commits, a C++23 compiler, CMake, Python 3.9 or later and Tau's documented
build dependencies. Spot's `ltlsynt` must be on `PATH` for the LTL tests.
The measurements here used macOS 26.6.2, Apple M3 Max, 128 GiB RAM, Homebrew
Clang 22.1.2, the Command Line Tools macOS 15.5 SDK, and Spot 2.15.1.
The preset was `release-tests`, with its default seven algebras and LTO enabled.

From this package directory, create two source trees:

```sh
bundle="$(pwd)"
git clone https://github.com/IDNI/tau-lang.git tau-unmodified
git -C tau-unmodified checkout --detach 92b760179ac6412270e54369a2d225dd226fdf18
git -C tau-unmodified submodule update --init --recursive
git clone https://github.com/IDNI/tau-lang.git tau-patched
git -C tau-patched checkout --detach 92b760179ac6412270e54369a2d225dd226fdf18
git -C tau-patched submodule update --init --recursive
git -C tau-patched apply "$bundle/patches/case-split-growth.patch"
```

For a quick review, build just the `tau` target below and run the small
comparison in the next section. This avoids compiling every test executable.

On the measured Mac, the compiler wrappers in `tools/` explicitly select the
installed SDK. They make no machine-wide changes. Check their two compiler
paths against your installation. Apply the shared build corrections:

```sh
for tree in tau-unmodified tau-patched; do
    git -C "$tree/external/parser" apply "$bundle/patches/parser-darwin-build.patch"
    git -C "$tree" apply "$bundle/patches/cvc5-final-signature.patch"
    git -C "$tree" apply "$bundle/patches/test-label-macos.patch"
done
export PATH="$bundle/tools:$PATH"
export SDKROOT=/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk
export TAU_TEST_CXX="$bundle/tools/clang++"
export TAU_STORE_REMOTE=
export TAU_STORE_PUBLISH=OFF
for tree in tau-unmodified tau-patched; do
    (
        cd "$tree"
        ./dev preset release-tests -DTAU_BUILD_JOBS=8 -DTAU_STORE_KEEP=0 \
            -G 'Unix Makefiles' \
            -DCMAKE_C_COMPILER="$bundle/tools/clang" \
            -DCMAKE_CXX_COMPILER="$bundle/tools/clang++" \
            -DTAU_HOST_C_COMPILER="$bundle/tools/clang" \
            -DTAU_HOST_CXX_COMPILER="$bundle/tools/clang++" --target tau
    ) || exit
done
```

Use a fresh configure. The dependency signing correction signs the final
library bytes before the dependency manifest records them. Re-signing a
library already recorded in the store leaves its manifest inconsistent.

On Linux, use `./dev preset release-tests --target tau` in each checkout
and omit the Mac build corrections and wrappers. Linux was not retested for
this refined patch. The Python runner uses Unix process APIs and `ps`; this
package does not provide a Windows replay.

To repeat the complete default-suite validation after that build, keep the
same environment and run in each source tree:

```sh
cmake --build --preset release-tests -j8
ctest --preset release-tests -j8 --output-on-failure
```

The equivalent one-step command is the Mac `./dev preset` invocation above
with `--target tau` replaced by `run`, or `./dev preset release-tests run`
on Linux. The complete Mac validation used that one-step form.

The default preset omits the C++ suites named in its `TAU_SKIP_TESTS` list;
those omissions are upstream defaults, not a claim that every available
optional suite ran. The additional `release-tests-bvonly` and
`release-tests-nobv` checks are described in `RESULTS.md`.

## Check answers and performance

From the package directory, using the two built executables:

```sh
python3 repro/check_outputs.py \
    --unmodified tau-unmodified/build/release/tau \
    --patched tau-patched/build/release/tau --out output-checks
python3 repro/check_wide.py \
    --unmodified tau-unmodified/build/release/tau \
    --patched tau-patched/build/release/tau --out wide-checks
python3 repro/check_controls.py \
    --unmodified tau-unmodified/build/release/tau \
    --patched tau-patched/build/release/tau \
    --inputs repro/inputs --out controller-checks
python3 repro/measure.py \
    --unmodified tau-unmodified/build/release/tau \
    --patched tau-patched/build/release/tau --out small-comparison \
    terms:8:spec terms:12:spec terms:14:spec
```

The answer checks use 517 input combinations, each in three configurations:
baseline, patched with default budget 8, and baseline with case splitting
disabled. Expected values come from unsigned integer comparisons. Both
outputs and their step numbers are checked. The controller checks compare
baseline with candidate budgets 1, 2, 8 and unlimited, and also check known
output values. `0` in the option means unlimited.

Each measurement point uses three fresh processes per variant and retains
every input, stdout, stderr, exit status and attempt. A failed attempt stops
the run. Timings include process startup, rule loading and checked steps.
CPU, wall time and Tau's stage timings are stored separately. Peak RSS comes
from the process resource record. The 60-second and sampled 1,536-MiB process
limits are runner safeguards, not limits supplied by the proposed patch.
Stop competing builds before collecting timings.

The full retained size comparison is:

```sh
python3 repro/measure.py \
    --unmodified tau-unmodified/build/release/tau \
    --patched tau-patched/build/release/tau --out size-comparison \
    terms:8:spec terms:9:spec terms:10:spec terms:12:spec terms:14:spec \
    terms:20:spec:unmodified terms:32:spec:unmodified terms:64:spec:unmodified \
    chain:8:spec chain:12:spec chain:16:spec \
    chain:24:spec:unmodified chain:32:spec:unmodified chain:64:spec:unmodified \
    terms:8:revision terms:10:revision chain:12:revision
```

Larger baseline points are deliberately excluded. They establish no speedup
ratio. Run the controller checker three times with distinct output directories
and `--timings` to reproduce the additional 60 timed processes.

## Read the evidence

`evidence/summary.json` contains medians and build identities.
The adjacent measurement directories retain all 195 timed process records.
`evidence/output-checks/` retains the six independent-reference runs covering
1,551 input evaluations. `evidence/wide-checks/` retains 12 additional processes
covering 54 input evaluations with 384-bit declarations on both loading paths.
The wider checks use the generator's small numeric IDs/keys, not arbitrary
high-bit values, and are not repeated timing estimates. JSON command paths are made relative to the package;
raw inputs and outputs are unchanged, and their recorded hashes verify.
`RESULTS.md` explains scope, limitations and test results.
