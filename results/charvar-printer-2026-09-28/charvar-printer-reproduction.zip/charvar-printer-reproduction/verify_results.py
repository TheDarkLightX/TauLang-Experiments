#!/usr/bin/env python3
"""Verify the retained observations without building Tau."""
import hashlib
import json
from pathlib import Path

from check import CASES, evaluate, variables

root = Path(__file__).resolve().parent
for line in (root / "SHA256SUMS").read_text().splitlines():
    digest, name = line.split("  ", 1)
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name

original = json.loads((root / "original-roundtrips.json").read_text())
corrected = json.loads((root / "corrected-roundtrips.json").read_text())
assert not original["passed"]
assert len(original["cases"]) == 9
assert sum(row["passed"] for row in original["cases"]) == 4
assert corrected["passed"]
assert original["default_charvar_output"] == corrected["default_charvar_output"]
assert len(corrected["cases"]) == len(CASES)
for row, (name, command, expression) in zip(corrected["cases"], CASES):
    assert (row["name"], row["command"], row["expected_expression"]) == (name, command, expression)
    assert row["passed"] and row["repeat_matches"] and row["no_new_variables"]
    assignments = row["assignments"]
    assert len(assignments) == 2 ** len(variables(expression))
    seen = set()
    for check in assignments:
        assert set(check["values"]) == variables(expression)
        key = tuple(sorted(check["values"].items()))
        assert key not in seen
        seen.add(key)
        expected = "F" if evaluate(expression, check["values"]) else "T"
        assert check["expected"] == check["actual"] == expected
        assert check["passed"]
for report in (original, corrected):
    assert len(report["controls"]) == 4
    assert all(row["passed"] for row in report["controls"])
suite = json.loads((root / "release-tests.json").read_text())
assert suite["returncode"] == 0
assert all(test["status"] == "passed" for test in suite["tests"])
assert len(suite["tests"]) == suite["registered_tests"] == 2369
print("Verified nine corrected round trips, 48 truth-table assignments, controls, and 2,369 retained Release test results.")
