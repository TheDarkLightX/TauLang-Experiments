# Preserve conjunctions when multi-character names are enabled

With `charvar=false`, separate variable names can be merged by the printer.
For example, printing `x & y` can produce `xy`, which the same grammar reads
as one variable. The correction prints `&` between conjunction operands in
this mode. The default `charvar=true` form keeps its existing spelling.

## Source and requirements

- Tau: `fd536d56e00f12187cbed123c67a735a6964c660` (`0.7.0-alpha`).
- Parser: `5b14b6fde86f16dc52c4c0a953a8a1e53c88f95a`.
- Python 3.9 or newer, CMake, a supported C++23 compiler, and Tau's
  [documented build dependencies](https://github.com/IDNI/tau-lang/blob/fd536d56e00f12187cbed123c67a735a6964c660/README.md#compiling-the-source-code).
- The recorded run used macOS 26.6.2 arm64 and Clang 22.1.2, Release
  (`-O3 -DNDEBUG`), the default `tau,qint,qlt,nlang,bv,sbf,hsb` type pack,
  cache and parser measurement enabled, and disabled LTO and artifact
  preinstantiation. No timing claim is made.

## Check the retained results

From this extracted directory:

```sh
python3 verify_results.py
```

This verifies checksums, recomputes the Boolean expected answers, compares
the recorded original and corrected outcomes, and checks the retained
Release test results. It does not run Tau.

## Build the original and corrected executables

Keep the extracted package as `charvar-printer-reproduction` beside two
new source directories. From their parent directory:

```sh
git clone https://github.com/IDNI/tau-lang.git tau-original
git -C tau-original checkout fd536d56e00f12187cbed123c67a735a6964c660
git -C tau-original submodule update --init --recursive
git clone https://github.com/IDNI/tau-lang.git tau-corrected
git -C tau-corrected checkout fd536d56e00f12187cbed123c67a735a6964c660
git -C tau-corrected submodule update --init --recursive
git -C tau-corrected apply ../charvar-printer-reproduction/charvar-printer.patch
```

In each source directory, build with the same compiler and options:

```sh
./dev preset release-tests -DTAU_BUILD_JOBS=4 -DTAU_LTO=OFF \
  -DTAU_ARTIFACT_PREINST=OFF -DTAU_DONT_USE_FTXUI=ON \
  -DTAU_PARSER_DONT_USE_FTXUI=ON
```

CMake must find the installed dependencies. The recorded Homebrew setup
selected its LLVM `clang` and `clang++` explicitly, supplied the installed
`CVC5_DIR`, and added the installed ICU library directory to
`CMAKE_EXE_LINKER_FLAGS`. These locations depend on the machine.

## Run the checks

From the common parent directory:

```sh
python3 charvar-printer-reproduction/check.py \
  --tau tau-original/build/release/tau --output original-replay.json
python3 charvar-printer-reproduction/check.py \
  --tau tau-corrected/build/release/tau --output corrected-replay.json
```

The original checker run is expected to exit 1: five of nine examples fail.
The corrected run should exit 0. Each command uses a fresh process and a
12-second timeout. Diagnostics, extra output, missing answers, nonzero
exits and timeouts fail a check. Existing output files are not overwritten.

The checker takes the actual text printed by `normalize` or `qelim`, then
reparses it with each Boolean assignment to its original free variables.
Python computes all 48 expected results independently. It also rejects new
variable names, repeats the printing calls, and includes true/false controls
in both naming modes. For the quantified example, eliminating `x0` from
`(x0 & y0) ^ z = 0` requires `z & y0' = 0`; the truth table checks that
result. These finite examples do not prove every possible print-and-parse
case correct.

In `tau-corrected`, run the API regression and the configured Release suite:

```sh
./build/release/test_api-tref_api --test-case=set_charvar
ctest --preset release-tests --parallel 4 --timeout 180 --output-on-failure
```

The API regression checks the parsed structure, including names and types,
while ignoring the order and grouping of conjunction/disjunction operands.
It also switches the setting off, on, off and on in one process.

The preset excludes some optional suites by default. The recorded run adds
`test_tau_tree_printers` to that preset and keeps its other exclusions,
for 2,369 registered tests, all passing. The additional printer suite has
4 cases and 50 assertions; the focused API regression has 30 assertions.
To register and build that extra suite before running CTest, run
`python3 ../charvar-printer-reproduction/enable_printer_test.py` from the
source directory. `release-tests.json` lists each registered test's
result. Tests that compile generated programs need working child compilers:
the recorded macOS run selected GCC 15.2.0 for `g++`, Clang 22.1.2 through
`TAU_CXX`, and the installed ICU library directory through `LDFLAGS`.

## Files

- `charvar-printer.patch`: correction and API regression.
- `check.py`: live checks and independent expected-value calculation.
- `original-roundtrips.json`, `corrected-roundtrips.json`: complete selected
  process observations, expected answers and comparisons.
- `release-tests.json`, `api-settings-test.txt`, `printer-unit-test.txt`:
  recorded test results.
- `build-info.json`: source, compiler, configuration and binary identities.
- `SHA256SUMS`: checksums of package members.

The patch uses the existing process-wide API/printer settings. This report
makes no new thread-safety or performance claim.

## Limited compatibility check

The printing correction also built with the complete patches published in
[#183](https://github.com/IDNI/tau-lang/issues/183) and
[#184](https://github.com/IDNI/tau-lang/issues/184). That build passed the
nine printing examples, 48 Boolean assignments, four controls, and the two
arithmetic regression examples across both preprocessing settings and split
budgets 0 and 2 (eight comparisons). `compatibility-summary.json` records
this limited check. The full 2,369-test suite was run for the printing
correction alone, not for the combined build.
