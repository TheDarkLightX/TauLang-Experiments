"""Finite safety-game certificate for the two retained lookback inputs.

This independently checks the explicitly stated game interpretation; it does
not use Tau's parser, temporal normalization, or the proposed BDD method.
"""
import copy,hashlib,itertools,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CASES=json.loads((ROOT/'timing-cases.json').read_text())
def relation(width,older,previous,input_value,output):
    mask=(1<<width)-1
    first=(previous|output)==(previous^older)
    second=(previous & (~input_value & mask))==0
    third=((input_value & (older^previous))==0) and older==(older|input_value)
    return first != (second == third)
def verify(width,states,moves):
    domain=range(1<<width);states=set(map(tuple,states))
    assert (0,0) in states
    assert set(moves)=={(a,b,i) for a,b in states for i in domain}
    for (a,b,i),c in moves.items():
        assert c in domain and relation(width,a,b,i,c) and (b,c) in states
    return True
results=[]
for w in [1,3]:
    case=next(c for c in CASES if c['name']=='temporal-lookback-width'+str(w))
    # Pin the exact expression translated by relation(), including grouping.
    template="sat always (((o1[t-1]:bv[{w}] | o1[t]:bv[{w}]) = (o1[t-1]:bv[{w}] ^ o1[t-2]:bv[{w}]) ^^ ((o1[t-1]:bv[{w}] & (i1[t]:bv[{w}])') = 0 <-> ((i1[t]:bv[{w}] & (o1[t-2]:bv[{w}] ^ o1[t-1]:bv[{w}])) = 0 && o1[t-2]:bv[{w}] = (o1[t-2]:bv[{w}] | i1[t]:bv[{w}])))))."
    assert case['source']==template.format(w=w)
    values=range(1<<w);winning=set(itertools.product(values,repeat=2));sizes=[len(winning)]
    while True:
        reduced={(a,b) for a,b in winning if all(any(relation(w,a,b,i,c) and (b,c) in winning for c in values) for i in values)}
        sizes.append(len(reduced))
        if reduced==winning:break
        winning=reduced
    moves={(a,b,i):next(c for c in values if relation(w,a,b,i,c) and (b,c) in winning) for a,b in winning for i in values}
    assert verify(w,winning,moves)
    controls=[]
    for name in ['wrong-move','missing-move']:
        changed=dict(moves)
        if name=='wrong-move':changed[0,0,0]=0
        else:del changed[0,0,0]
        try:verify(w,winning,changed)
        except AssertionError:controls.append(dict(name=name,rejected=True))
        else:raise AssertionError(name+' was accepted')
    results.append(dict(name=case['name'],width=w,source=case['source'],source_sha256=hashlib.sha256(case['source'].encode()).hexdigest(),winning_states=sorted(winning),iteration_sizes=sizes,initial_history=[0,0],strategy=[dict(older=a,previous=b,input=i,output=c) for (a,b,i),c in sorted(moves.items())],checked_moves=len(moves),negative_controls=controls))
output=dict(passed=True,interpretation='At each constrained time, observe the current input, choose the current output, and advance (older, previous) to (previous, output). The first two outputs may initialize the history; both zero belong to the invariant.',claim='For each retained width, every state in the listed nonempty invariant and every input has a checked output satisfying the displayed relation and returning to the invariant. Induction gives a causal infinite strategy under this game interpretation.',limits='This is a finite integer certificate, not a new verification of Tau parsing, time initialization rules, temporal normalization, or the complete implementation.',results=results)
(ROOT/'temporal-invariant-check.json').write_text(json.dumps(output,indent=2)+'\n')
print({'passed':True,'widths':[r['width'] for r in results],'winning_state_counts':[len(r['winning_states']) for r in results],'checked_moves':sum(r['checked_moves'] for r in results),'negative_controls':sum(len(r['negative_controls']) for r in results)})
