"""Recompute expected answers and bind them to the portable check inputs."""
import json,runpy
from pathlib import Path
ROOT=Path(__file__).resolve().parent
cases=json.loads((ROOT/'finite-cases.json').read_text())
expected=[]
for name in ['new_cases.json','unsupported_cases.json']:
    for c in json.loads((ROOT/'inputs'/name).read_text())['cases']:
        expected.append(dict(name=c['id'],source='normalize '+c['formula']+'.',expected=c['truth']))
assert cases==expected and len(cases)==270
runpy.run_path(str(ROOT/'check_broader_expectations.py'),run_name='__main__')
runpy.run_path(str(ROOT/'check_unsupported_expectations.py'),run_name='__main__')
print('All 270 portable inputs match the independently checked expectations.')
