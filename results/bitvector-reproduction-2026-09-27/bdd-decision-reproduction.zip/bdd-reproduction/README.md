# Bounded BDD decision for bit-vector formulas

This package compares two source builds at Tau `fd536d56e00f12187cbed123c67a735a6964c660`, parser `5b14b6fde86f16dc52c4c0a953a8a1e53c88f95a`:

- Reference: the arithmetic elimination correction only.
- Candidate: the same correction plus the BDD decision method.

The correction is present in both builds because an earlier arithmetic rewrite can otherwise return a wrong answer before the decision method runs. The optimization patch adds both required headers. No downloaded executable is needed.

## Build

Install the dependencies in Tau's README for your platform. From this package directory:

```sh
git clone https://github.com/IDNI/tau-lang.git tau-reference
git -C tau-reference checkout fd536d56e00f12187cbed123c67a735a6964c660
git -C tau-reference submodule update --init --recursive
git -C tau-reference apply --check ../arithmetic-elimination.patch
git -C tau-reference apply ../arithmetic-elimination.patch
git clone https://github.com/IDNI/tau-lang.git tau-candidate
git -C tau-candidate checkout fd536d56e00f12187cbed123c67a735a6964c660
git -C tau-candidate submodule update --init --recursive
git -C tau-candidate apply --check ../arithmetic-elimination.patch
git -C tau-candidate apply ../arithmetic-elimination.patch
git -C tau-candidate apply --check ../bdd-decision.patch
git -C tau-candidate apply ../bdd-decision.patch
```

Run this inside each checkout with the same compiler and dependencies:

```sh
./dev preset release-tau -DTAU_LTO=OFF -DTAU_ARTIFACT_PREINST=OFF -DTAU_DONT_USE_FTXUI=ON -DTAU_PARSER_DONT_USE_FTXUI=ON -DTAU_BUILD_JOBS=2
```

Add platform-specific compiler and dependency paths as needed. Return to the package directory for the remaining commands. Python 3.9 or later is sufficient.

## Check the expected answers, then Tau

```sh
python3 check_expectations.py
python3 compare.py check --reference tau-reference/build/release/tau --candidate tau-candidate/build/release/tau --output replay-check
```

The first command independently parses and enumerates 240 small finite formulas. For another 30 examples, it checks that the other parts of each formula settle the answer for either possible truth value of its unsupported operation. It also checks that these are exactly the 270 formulas sent to Tau.

The second command performs 1,350 processes: the reference once per formula, and the candidate with default settings, BDD disabled, and both BDD thresholds set to 1 or 64 nodes. Every expected answer must match. Nonzero exits, stderr, missing or extra output, wrong answers and 90-second timeouts stop the check. Output directories must be new.

## Measure

```sh
python3 compare.py measure --reference tau-reference/build/release/tau --candidate tau-candidate/build/release/tau --output replay-timing
```

This runs all seven retained timing examples in seven deterministically shuffled blocks. Each invocation starts a new Tau process. The default five-second limit is recorded as a timeout; it is never used as a completed duration. Medians include only completed correct runs. A paired ratio is reported only for blocks in which both versions complete. Do not compare these figures with repeated calls inside an already running process.

Both commands explicitly set `--preprocessing=false --block-max-splits=0`, disable bit-vector widening and the separate quantifier-free decision option, and clear inherited bit-vector decision environment overrides. The BDD thresholds remain at their default 16,384 nodes. `-p` means the block split limit, not preprocessing. To repeat the separate limited-splitting experiment, use `--block-max-splits 2` and a new output directory.

The temporal examples print a normalization result before the final answer. The measurement checker recognizes that complete output format and retains it. Unexpected output still fails.

## Meaning and limits

[ALGORITHM.md](ALGORITHM.md) explains bit encoding, factor elimination, binder order and fallback behavior. Node thresholds are cooperative; they are not hard time or memory limits. The method can add overhead before falling back to the original solver.

`python3 check_temporal_invariant.py` independently checks a finite strategy for each temporal example under an explicitly stated safety-game interpretation. This supports the expected answer under that interpretation; it does not independently verify Tau's parser, initialization rules or temporal normalization.

The seven timing inputs are selected examples, not a representative application sample. No universal speedup, general correctness proof, or guarantee of concurrent/reentrant use is claimed. The measured patch and packaged patch have identical executable changes; only explanatory comments were refined. `RESULTS.md` records the completed measurements and their limits.
