# How the bit-vector decision method works

A binary decision diagram (BDD) represents a Boolean function as a graph of choices about individual bits. Equal remaining functions share the same graph nodes. Sharing can make some quantified bit-vector formulas much smaller, but the graph can still grow exponentially.

## Keep the operation meanings

Each bit-vector variable becomes one Boolean variable per bit. Bits of equal significance from different words sit next to each other in the decision order. Bitwise operations use the corresponding Boolean operations. Addition and subtraction carry or borrow between bits and wrap at the declared width. Comparisons, minimum and maximum use unsigned order.

Before computing an answer, the method checks the entire input for supported operators and consistent widths. Multiplication, division, remainder, shifts and other unsupported nodes cause a decline. This check comes before simplifications that might otherwise hide an unsupported part of the input.

## Eliminate a variable as soon as its factors are joined

Suppose a conjunction has factors `A(x,u)`, `B(x,v)` and `C(u,v)`. Only the first two mention `x`, so:

```text
exists x. (A(x,u) AND B(x,v) AND C(u,v))
=
(exists x. (A(x,u) AND B(x,v))) AND C(u,v)
```

The method joins the factors that mention the chosen variable, eliminates that variable, then keeps the resulting diagram with the remaining factors. Universal quantifiers use the dual identity over disjunctions. Within a consecutive block of the same kind of quantifier, it first eliminates the variable that would add the fewest new connections between remaining variables. Ties prefer fewer neighboring variables, then the original binder order. This is a size heuristic, not a guarantee of the smallest possible diagram.

Quantifiers of opposite kinds retain their order. For example, `all x ex y (x=y)` is true, but `ex y all x (x=y)` is false when the domain has more than one value. The first permits `y` to depend on `x`; the second requires one `y` for every `x`. Reordering across that boundary would change the problem.

The method remembers repeated subexpressions only while their variable bindings remain the same. It clears those remembered values when entering or leaving a quantifier scope. Nested reuse of a variable name therefore keeps its local meaning.

## Decline without inventing an answer

Two options control cooperative node thresholds: one for queries containing arithmetic or comparisons, and one for the other supported queries. Both default to 16,384 nodes. Exceeding a threshold abandons this method and leaves the query to the existing solver paths.

These are not hard time or memory limits. A step between checks can invoke several recursive diagram operations. The separate table capacity and its exhaustion check must also be respected. A declined query can pay for the diagram attempt before paying for the original solver, so unsupported and difficult cases need performance measurements as well as answer checks.

This optimization does not repair an incorrect earlier rewrite. The arithmetic elimination correction is therefore tested separately and included equally in all four comparison builds. Agreement between builds is supplemented by independently computed finite answers.

## Limits of the evidence

The retained checks cover finite formulas, binding order, repeated calls, disabled and small-threshold settings, and direct calls to the decision methods. They do not prove correctness for every formula, optimal ordering, bounded elapsed time, safe concurrent or reentrant use, or a speedup for every application. End-to-end tests on temporal specifications exercise the surrounding Tau pipeline; this is not a new temporal decision procedure.
