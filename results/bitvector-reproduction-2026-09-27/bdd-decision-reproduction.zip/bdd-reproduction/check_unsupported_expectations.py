"""Verify each unsupported-operation example is settled by its other factor."""
import hashlib,itertools,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import oracle
source=ROOT/'inputs/unsupported_cases.json';cases=json.loads(source.read_text())['cases'];rows=[]
for c in cases:
    widths=set(map(int,re.findall(r'bv\[(\d+)\]',c['formula'])));assert len(widths)==1
    w=widths.pop();op=c['op'];target=f'((x:bv[{w}] {op} y:bv[{w}]) = {{1}}:bv[{w}])'
    assert c['formula'].count(target)==1
    checked=0
    for value in ['T','F']:
        parsed=oracle.parse(c['formula'].replace(target,value));q=parsed.args[0]
        assert parsed.op==q.op==('all' if c['truth'] else 'ex') and parsed.value=='x' and q.value=='y'
        body=q.args[0]
        for x,y in itertools.product(range(1<<w),repeat=2):
            assert oracle.evaluate(body,{'x':oracle.BV(x,w),'y':oracle.BV(y,w)})==c['truth'];checked+=1
    rows.append(dict(id=c['id'],expected=c['truth'],pointwise_checks=checked))
result=dict(passed=True,distinct_formulas=len(rows),pointwise_checks=sum(r['pointwise_checks'] for r in rows),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),basis='At every x/y value, the surrounding formula is already true or false independently of either truth value of the unsupported relation. This does not test whether the BDD route was entered.',records=rows)
(ROOT/'unsupported-expectations-rechecked.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='records'})
