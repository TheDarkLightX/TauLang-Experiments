#!/usr/bin/env python3
"""Check finite answers or measure complete Tau processes from two source builds."""
import argparse,hashlib,json,os,random,re,statistics,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
OPTIONS=['--charvar=false','--color=false','--highlighting=false','--benchmarks=false','--status=false','--bv-widening=false','--bv-quantifier-free-decision=false']
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('phase',choices=['check','measure'])
    p.add_argument('--reference',type=Path,required=True)
    p.add_argument('--candidate',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--blocks',type=int,default=7)
    p.add_argument('--timeout',type=float,default=5)
    p.add_argument('--block-max-splits',type=int,choices=[0,2],default=0)
    p.add_argument('--preprocessing',choices=['false','true'],default='false')
    a=p.parse_args()
    if a.blocks<1 or a.timeout<=0:p.error('blocks and timeout must be positive')
    a.output.mkdir(parents=True,exist_ok=False)
    binaries={name:getattr(a,name).resolve() for name in ['reference','candidate']}
    env=os.environ.copy()
    for key in list(env):
        if key.startswith(('TAU_BV_','TAU_TREF_BUDGET')):env.pop(key)
    cases=json.loads((HERE/('finite-cases.json' if a.phase=='check' else 'timing-cases.json')).read_text())
    blocks=1 if a.phase=='check' else a.blocks
    limit=90 if a.phase=='check' else a.timeout
    receipt=dict(status='running',phase=a.phase,binary_sha256={n:hashlib.sha256(b.read_bytes()).hexdigest() for n,b in binaries.items()},distinct_inputs=len(cases),blocks=blocks,timeout_seconds=limit,preprocessing=a.preprocessing=='true',block_max_splits=a.block_max_splits)
    def save(): (a.output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    save();rows=[]
    try:
        with (a.output/'records.jsonl').open('w') as out:
            for block in range(blocks):
                jobs=[(c,n,m) for c in cases for n in binaries for m in (['default','disabled','cap1','cap64'] if a.phase=='check' and n=='candidate' else ['default'])]
                random.Random(2026092730+block).shuffle(jobs)
                for c,name,mode in jobs:
                    options=[]
                    if mode=='disabled':options=['--bv-bdd-decision=false']
                    elif mode.startswith('cap'):options=['--bv-bdd-max-nodes='+mode[3:],'--bv-bdd-max-nodes-arith='+mode[3:]]
                    start=time.perf_counter_ns()
                    try:
                        r=subprocess.run([str(binaries[name]),*OPTIONS,*options,'--preprocessing='+a.preprocessing,'--block-max-splits='+str(a.block_max_splits),'-e',c['source']],capture_output=True,text=True,stdin=subprocess.DEVNULL,env=env,timeout=limit)
                        row=dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr,timeout=False)
                    except subprocess.TimeoutExpired as e:
                        decode=lambda v:v.decode(errors='replace') if isinstance(v,bytes) else v or ''
                        row=dict(exit=None,stdout=decode(e.stdout),stderr=decode(e.stderr),timeout=True)
                    row.update(name=c['name'],arm=name,mode=mode,block=block,expected=c['expected'],process_ns=time.perf_counter_ns()-start)
                    output=row['stdout'].strip()
                    valid_output=output=='%1: '+('T' if c['expected'] else 'F')
                    if c['source'].startswith('sat always '):
                        match=re.fullmatch(r'Temporal normalization of G specification reached fixpoint after [1-9][0-9]* steps, yielding the result: \n[^\n]+\n\n%1: ([TF])',output)
                        valid_output=bool(match) and match.group(1)==('T' if c['expected'] else 'F')
                    row['correct']=row['exit']==0 and not row['stderr'] and valid_output
                    rows.append(row);out.write(json.dumps(row)+'\n');out.flush()
                    if not row['correct'] and not (a.phase=='measure' and row['timeout']):raise RuntimeError('Check failed: '+c['name']+' / '+name+' / '+mode)
        if a.phase=='measure':
            index={(r['name'],r['arm'],r['block']):r for r in rows};summary=[]
            for c in cases:
                item=dict(name=c['name'],arms={},paired_ratio_reference_over_candidate=None,completed_pairs=0)
                for name in binaries:
                    part=[index[c['name'],name,b] for b in range(blocks)];times=[r['process_ns']/1e6 for r in part if r['correct']]
                    item['arms'][name]=dict(completed=len(times),timeouts=sum(r['timeout'] for r in part),median_completed_ms=statistics.median(times) if times else None)
                ratios=[index[c['name'],'reference',b]['process_ns']/index[c['name'],'candidate',b]['process_ns'] for b in range(blocks) if index[c['name'],'reference',b]['correct'] and index[c['name'],'candidate',b]['correct']]
                item.update(completed_pairs=len(ratios),paired_ratio_reference_over_candidate=statistics.median(ratios) if ratios else None);summary.append(item)
            (a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        receipt.update(status='passed',processes=len(rows),timeouts=sum(r['timeout'] for r in rows));save();print(json.dumps(receipt,indent=2));return 0
    except Exception as e:
        receipt.update(status='failed',error=str(e),processes=len(rows));save();raise
if __name__=='__main__':raise SystemExit(main())
