"""Check retained small-domain expectations without running Tau."""
import hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import oracle
REL_NEG={'!<':'>=','!<=':'>','!>':'<=','!>=':'<'}
def convert(a):
    op=a[0]
    if op=='v':return oracle.Node('var',value=a[2],width=a[1])
    if op=='c':return oracle.Node('const',value=a[2],width=a[1])
    if op in ('all','ex'):return oracle.Node(op,(convert(a[3]),),a[1],a[2])
    if op=='not':return oracle.Node('!',(convert(a[1]),))
    if op=='rel':return oracle.Node(REL_NEG.get(a[1],a[1]),(convert(a[2]),convert(a[3])))
    start=1 if op in ('&&','||','->','<->') else 2
    return oracle.Node(op,tuple(convert(c) for c in a[start:]))
def main():
    source=ROOT/'inputs/new_cases.json';cases=json.loads(source.read_text())['cases'];rows=[]
    oracle.self_test()
    for c in cases:
        text=re.sub(r'!<=|!>=|!<|!>',lambda m:REL_NEG[m[0]],c['formula'])
        parsed=oracle.parse(text);stored=convert(c['ast'])
        assert parsed==stored,('stored syntax disagrees with parsed formula',c['id'])
        answer=oracle.evaluate(parsed);assert type(answer) is bool and answer==c['truth'],c['id']
        rows.append(dict(id=c['id'],answer=answer))
    assert len(rows)==240
    result=dict(passed=True,distinct_formulas=len(rows),true=sum(r['answer'] for r in rows),false=sum(not r['answer'] for r in rows),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),evaluator_sha256=hashlib.sha256(Path(oracle.__file__).read_bytes()).hexdigest(),scope='240 retained finite formulas, independently parsed and enumerated with the committed integer evaluator. Negated unsigned relations are expanded to their exact complements before parsing. The stored ASTs must equal the parsed trees. Unsupported cases and temporal specifications are outside this check.',answers=rows)
    (ROOT/'broader-expectations-rechecked.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='answers'})
if __name__=='__main__':main()
