# Recorded results

Seven shuffled blocks on an Apple M3 Max, 128 GiB RAM, macOS 26.6.2, Clang 22.1.2, cvc5 1.3.1. Both source builds use Release, the same arithmetic correction, preprocessing disabled, unlimited block splitting, widening disabled and the separate quantifier-free decision option disabled. BDD thresholds are the defaults. Complete process durations include startup, parsing and output.

| Example | Correction only | Correction + BDD |
|---|---:|---:|
| alternating-sum-64 | 46.196 ms | 49.792 ms |
| sum-reordering-64 | 50.581 ms | 53.619 ms |
| comparison-chain-64 | 89.924 ms | 94.569 ms |
| equality-clauses-64 | 177.195 ms | 177.498 ms |
| temporal-lookback-width3 | 7/7 runs exceeded 5 s | 78.496 ms |
| temporal-lookback-width1 | 163.525 ms | 64.192 ms |
| carry-identity-32 | 42.250 ms | 39.317 ms |

These are the reference and BDD columns from a four-build run. Every completed process returned the expected answer with zero exit and empty stderr. The three-bit reference timings are censored at five seconds; there is no exact completed reference median or exact speedup ratio. The one-bit temporal median paired reference/BDD ratio was 2.557, with seven wins. The alternating-sum paired ratio was 0.919, an approximately 8.8% cost increase by the reciprocal paired ratio. There is no universal gain.

The full 196-process raw run and all four columns are retained in `recorded/default-split/`. Its names are defined here: `unchanged` is correction only, `sum` adds the modular-sum graph method, `bdd` adds BDD, and `combined` adds both. The original `source_path` metadata has been removed from the copied case list; formulas and all timing samples are unchanged. Only the two reference/BDD columns are needed for this package.

`recorded/finite-check/` contains 1,350 passing checks on 270 inputs. The initial checker version used the same finite-input validation; the packaged version additionally recognizes Tau's normal temporal information output. Its measurement phase passed a separate 14-process, one-block replay in `recorded/portable-measure-check/`. That one-block replay validates packaging and is not pooled with the seven-block measurements.

The finite and temporal expectation scripts, their generated results, all source patches and SHA-256 manifest are included. The patch stack was applied to the pinned unmodified source and reverse-checked against the complete measured-change publication patch. Only explanatory comments differ from the measured code.
