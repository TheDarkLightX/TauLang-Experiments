# Wrong bit-vector results during quantifier elimination

This package contains two small examples, 1,158 retained examples with independently checked expected answers, a finite Python evaluator, and the one-file arithmetic elimination correction.

Source pins:

- Tau: `fd536d56e00f12187cbed123c67a735a6964c660`
- Parser: `5b14b6fde86f16dc52c4c0a953a8a1e53c88f95a`
- Patch SHA-256: `40bfb9046583dcfe1205d3caff9bed98e70b67ae4bea7cf63d553ac86932a6c2`

## Build

Install the dependencies in Tau's README for your platform. Use the same compiler, dependencies and flags for the original and corrected builds.

```sh
git clone https://github.com/IDNI/tau-lang.git tau-original
git -C tau-original checkout fd536d56e00f12187cbed123c67a735a6964c660
git -C tau-original submodule update --init --recursive
git clone https://github.com/IDNI/tau-lang.git tau-corrected
git -C tau-corrected checkout fd536d56e00f12187cbed123c67a735a6964c660
git -C tau-corrected submodule update --init --recursive
git -C tau-corrected apply --check ../arithmetic-elimination.patch
git -C tau-corrected apply ../arithmetic-elimination.patch
```

In each checkout, build Release with the default algebra pack:

```sh
./dev preset release-tau -DTAU_LTO=OFF -DTAU_ARTIFACT_PREINST=OFF -DTAU_DONT_USE_FTXUI=ON -DTAU_PARSER_DONT_USE_FTXUI=ON -DTAU_BUILD_JOBS=2
```

Add your platform's compiler and dependency paths if needed. No precompiled binary is required.

## Check

Return to this package directory. With Python 3.9 or later:

```sh
python3 check.py --tau tau-original/build/release/tau --minimal --preprocessing off --output replay-original-minimal.json
python3 check.py --tau tau-corrected/build/release/tau --minimal --output replay-corrected-minimal.json
python3 check.py --tau tau-corrected/build/release/tau --output replay-corrected-all.json
```

The original minimal check is expected to exit 1: each example has the wrong answer at split limits 0 and 2 with preprocessing disabled. The corrected checks should exit 0. Each command keeps all stdout, stderr, missing results, timeouts and wrong answers in its own JSON file. Existing result files are never overwritten. Each batch of at most 25 formulas has a 90-second limit; a timeout stops the run with a failed result.

The evaluator checks the formulas using finite integer enumeration without Tau or another solver. Arithmetic wraps at the declared width; comparisons are unsigned. It recomputes every expected answer before invoking Tau. The 1,158 examples are all previously observed failures; they are not a representative sample of applications or a general proof of correctness. They comprise 999 true formulas and 159 false formulas. The checker uses both explicit preprocessing settings (`false` and `true`) and both block-splitting limits (0 and 2). Limit 0 means unlimited splitting; preprocessing is a separate Boolean option. Repeating the formulas under four settings does not create new distinct examples.

The first minimal formula is true: for every `x`, take `y=(x&1)+2` modulo 8. The second is false: at `x=0`, none of the four two-bit values of `y` satisfies `(y&2)=(y-3)` modulo 4.

The patch keeps quantified variables when a modular arithmetic operation or unsigned comparison depends on them. The existing solver paths can then decide the remaining formula. It does not change the bit-mask screening rule or add a BDD optimization.

The patch differs from the measured source only in the explanatory comment above the guard. The comment uses the explicit three-bit endpoints 6 and 5. All executable changes are identical.

## Recorded checks

The included `original-minimal.json` records four wrong answers. `corrected-minimal.json` records eight correct answers. `corrected-all.json` records 4,632 correct checks across 1,158 distinct formulas, preprocessing disabled/enabled and split limits 0/2. The packaged checker was run against both binaries. Its controls reject wrong or missing answers, extra output, stderr, nonzero exits and timeouts; they also check that existing result files are preserved.
