#!/usr/bin/env python3
"""Recompute finite truth, then check explicit preprocessing and split settings."""
import argparse,hashlib,json,os,re,subprocess
from pathlib import Path
import oracle
HERE=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--tau',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--minimal',action='store_true')
    p.add_argument('--preprocessing',choices=['off','on','both'],default='both')
    p.add_argument('--timeout',type=float,default=90)
    args=p.parse_args();binary=args.tau.resolve()
    if args.timeout<=0:p.error('timeout must be positive')
    if args.output.exists():p.error('Choose a new output file to preserve earlier results.')
    cases=json.loads((HERE/'cases.json').read_text())
    if args.minimal:
        cases=[dict(id='minimal_'+str(i),source=s,expected=t) for i,(s,t) in enumerate(zip((HERE/'minimal.tau').read_text().splitlines(),[True,False]))]
    oracle.self_test()
    for c in cases:
        if oracle.decide(c['source'])!=c['expected']:raise ValueError('Stored expected answer disagrees with finite enumeration: '+c['id'])
    env=os.environ.copy()
    for key in list(env):
        if key.startswith(('TAU_BV_','TAU_TREF_BUDGET')):env.pop(key)
    options=['--charvar=false','--color=false','--highlighting=false','--benchmarks=false','--status=false','--bv-widening=false','--bv-quantifier-free-decision=false']
    preprocessing_values={'off':[False],'on':[True],'both':[False,True]}[args.preprocessing]
    result=dict(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),distinct_inputs=len(cases),oracle_sha256=hashlib.sha256((HERE/'oracle.py').read_bytes()).hexdigest(),block_max_splits=[0,2],preprocessing=preprocessing_values,timeout_seconds=args.timeout,batches=[],wrong_answers=0,incomplete_batches=0)
    for preprocess,split_limit in [(b,s) for b in preprocessing_values for s in [0,2]]:
        for start in range(0,len(cases),25):
            batch=cases[start:start+25];cmd=[str(binary),*options,'--preprocessing='+str(preprocess).lower(),'--block-max-splits='+str(split_limit),'-e','\n'.join(c['source'] for c in batch)]
            try:
                r=subprocess.run(cmd,capture_output=True,text=True,env=env,stdin=subprocess.DEVNULL,timeout=args.timeout)
                row=dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr,timeout=False)
            except subprocess.TimeoutExpired as e:
                decode=lambda v:v.decode(errors='replace') if isinstance(v,bytes) else v or ''
                row=dict(exit=None,stdout=decode(e.stdout),stderr=decode(e.stderr),timeout=True)
            output_lines=row['stdout'].strip().splitlines()
            matches=[re.fullmatch(r'%[1-9][0-9]*: ([TF])',line) for line in output_lines]
            valid_output=bool(matches) and all(matches)
            answers=[match.group(1) for match in matches if match]
            expected=['T' if c['expected'] else 'F' for c in batch]
            complete=row['exit']==0 and not row['stderr'] and not row['timeout'] and valid_output and len(answers)==len(batch)
            wrong=[c['id'] for c,a,t in zip(batch,answers,expected) if a!=t] if complete else []
            row.update(preprocessing=preprocess,block_max_splits=split_limit,ids=[c['id'] for c in batch],expected=expected,answers=answers,complete=bool(complete),wrong_ids=wrong)
            result['wrong_answers']+=len(wrong);result['incomplete_batches']+=not complete
            result['batches'].append(row);args.output.write_text(json.dumps(result,indent=2)+'\n')
            if row['timeout']:
                result.update(passed=False,stopped_reason='batch_timeout')
                args.output.write_text(json.dumps(result,indent=2)+'\n')
                return 1
    result['passed']=result['wrong_answers']==0 and result['incomplete_batches']==0 and all(not r['stderr'] for r in result['batches'])
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='batches'},indent=2))
    return 0 if result['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
