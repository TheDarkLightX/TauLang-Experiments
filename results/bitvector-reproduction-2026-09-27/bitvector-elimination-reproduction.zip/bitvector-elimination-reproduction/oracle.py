#!/usr/bin/env python3
"""Independent exhaustive evaluator for the closed Tau BV fragment used here.

It intentionally shares no Tau code.  Widths are explicit and arithmetic is
modular.  Comparisons/min/max are unsigned.  Free variables are rejected so
that every reported answer comes only from explicit finite enumeration.
"""

from __future__ import annotations

import argparse
import dataclasses
import itertools
import re
import sys
from typing import Iterator


@dataclasses.dataclass(frozen=True)
class Node:
    op: str
    args: tuple["Node", ...] = ()
    value: int | str | None = None
    width: int | None = None


@dataclasses.dataclass(frozen=True)
class BV:
    value: int
    width: int

    def __post_init__(self) -> None:
        if self.width < 1:
            raise ValueError("zero-width bitvector")
        object.__setattr__(self, "value", self.value & ((1 << self.width) - 1))


TOKEN_RE = re.compile(
    r"\s*(?:(?P<num>\d+)|(?P<id>[A-Za-z_][A-Za-z_0-9]*)|"
    r"(?P<op><->|->|&&|\|\||!=|<=|>=|!&|!\||!\^|[{}():,.[\]+\-&|^'=<>!]))"
)


def tokenize(text: str) -> list[str]:
    text = text.strip()
    if text.startswith("normalize "):
        text = text[len("normalize "):]
    if text.endswith("."):
        text = text[:-1]
    out: list[str] = []
    pos = 0
    while pos < len(text):
        m = TOKEN_RE.match(text, pos)
        if not m:
            raise SyntaxError(f"unrecognized input at offset {pos}: {text[pos:pos+30]!r}")
        out.append(m.group(m.lastgroup))
        pos = m.end()
    return out


class Parser:
    # Generated cases are fully parenthesized.  These precedences also accept
    # Tau's ordinary surface syntax for the operators in this campaign.
    PREC = {
        "<->": (10, 11),
        "->": (20, 20),       # right associative
        "||": (30, 31),
        "&&": (40, 41),
        "=": (50, 51), "!=": (50, 51),
        "<": (50, 51), "<=": (50, 51), ">": (50, 51), ">=": (50, 51),
        "|": (60, 61), "!|": (60, 61),
        "^": (65, 66), "!^": (65, 66),
        "&": (70, 71), "!&": (70, 71),
        "+": (80, 81), "-": (80, 81),
    }

    def __init__(self, text: str):
        self.tokens = tokenize(text)
        self.i = 0

    def peek(self) -> str | None:
        return self.tokens[self.i] if self.i < len(self.tokens) else None

    def take(self, expected: str | None = None) -> str:
        tok = self.peek()
        if tok is None:
            raise SyntaxError("unexpected end of input")
        if expected is not None and tok != expected:
            raise SyntaxError(f"expected {expected!r}, got {tok!r}")
        self.i += 1
        return tok

    def parse_type(self) -> int:
        self.take(":")
        self.take("bv")
        self.take("[")
        width = int(self.take())
        self.take("]")
        if not 1 <= width <= 4:
            raise ValueError(f"oracle is deliberately restricted to widths 1..4, got {width}")
        return width

    def parse(self) -> Node:
        node = self.expr(0)
        if self.peek() is not None:
            raise SyntaxError(f"trailing token {self.peek()!r}")
        return node

    def expr(self, min_bp: int) -> Node:
        left = self.atom()
        while True:
            tok = self.peek()
            if tok == "'":
                if 100 < min_bp:
                    break
                self.take()
                left = Node("'", (left,))
                continue
            if tok not in self.PREC:
                break
            lbp, rbp = self.PREC[tok]
            if lbp < min_bp:
                break
            self.take()
            right = self.expr(rbp)
            left = Node(tok, (left, right))
        return left

    def atom(self) -> Node:
        tok = self.take()
        if tok == "(":
            n = self.expr(0)
            self.take(")")
            return n
        if tok in ("all", "ex"):
            name = self.take()
            width = self.parse_type()
            # Tau quantifiers extend across their following formula.  Campaign
            # renderings put that formula in parentheses, avoiding ambiguity.
            body = self.expr(0)
            return Node(tok, (body,), name, width)
        if tok in ("min", "max"):
            self.take("(")
            a = self.expr(0)
            self.take(",")
            b = self.expr(0)
            self.take(")")
            return Node(tok, (a, b))
        if tok == "!":
            return Node("!", (self.expr(90),))
        if tok == "{":
            value = int(self.take())
            self.take("}")
            width = self.parse_type()
            return Node("const", value=value, width=width)
        if tok in ("T", "F"):
            return Node("bool", value=(tok == "T"))
        if re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", tok):
            width = self.parse_type() if self.peek() == ":" else None
            return Node("var", value=tok, width=width)
        raise SyntaxError(f"unexpected token {tok!r}")


def parse(text: str) -> Node:
    return Parser(text).parse()


def _same_bv(a: object, b: object) -> tuple[BV, BV]:
    if not isinstance(a, BV) or not isinstance(b, BV):
        raise TypeError(f"expected two bitvectors, got {a!r}, {b!r}")
    if a.width != b.width:
        raise TypeError(f"width mismatch: {a.width} != {b.width}")
    return a, b


def evaluate(node: Node, env: dict[str, BV] | None = None) -> bool | BV:
    if env is None:
        env = {}
    op = node.op
    if op == "const":
        assert isinstance(node.value, int) and node.width is not None
        return BV(node.value, node.width)
    if op == "bool":
        return bool(node.value)
    if op == "var":
        assert isinstance(node.value, str)
        if node.value not in env:
            raise ValueError(f"free variable {node.value!r}")
        value = env[node.value]
        if node.width is not None and value.width != node.width:
            raise TypeError(f"annotation for {node.value} disagrees with binder")
        return value
    if op in ("all", "ex"):
        assert isinstance(node.value, str) and node.width is not None
        old = env.get(node.value)
        existed = node.value in env
        answers: Iterator[bool] = (
            bool(evaluate(node.args[0], {**env, node.value: BV(v, node.width)}))
            for v in range(1 << node.width)
        )
        result = all(answers) if op == "all" else any(answers)
        # The copied environments above make restoration unnecessary; these
        # assertions document shadowing semantics explicitly.
        assert (node.value in env) == existed and env.get(node.value) == old
        return result
    if op == "!":
        a = evaluate(node.args[0], env)
        if not isinstance(a, bool):
            raise TypeError("formula negation applied to a bitvector")
        return not a
    if op == "'":
        a = evaluate(node.args[0], env)
        if not isinstance(a, BV):
            raise TypeError("bitwise complement applied to a formula")
        return BV(~a.value, a.width)

    a0 = evaluate(node.args[0], env)
    # Preserve logical short-circuiting without changing finite semantics.
    if op == "&&" and isinstance(a0, bool) and not a0:
        return False
    if op == "||" and isinstance(a0, bool) and a0:
        return True
    if op == "->" and isinstance(a0, bool) and not a0:
        return True
    b0 = evaluate(node.args[1], env)

    if op in ("&&", "||", "->", "<->"):
        if not isinstance(a0, bool) or not isinstance(b0, bool):
            raise TypeError(f"logical {op} requires formulas")
        return {"&&": a0 and b0, "||": a0 or b0,
                "->": (not a0) or b0, "<->": a0 == b0}[op]
    a, b = _same_bv(a0, b0)
    mask = (1 << a.width) - 1
    if op == "=": return a.value == b.value
    if op == "!=": return a.value != b.value
    if op == "<": return a.value < b.value
    if op == "<=": return a.value <= b.value
    if op == ">": return a.value > b.value
    if op == ">=": return a.value >= b.value
    if op == "+": return BV(a.value + b.value, a.width)
    if op == "-": return BV(a.value - b.value, a.width)
    if op == "&": return BV(a.value & b.value, a.width)
    if op == "|": return BV(a.value | b.value, a.width)
    if op == "^": return BV(a.value ^ b.value, a.width)
    if op == "!&": return BV((~(a.value & b.value)) & mask, a.width)
    if op == "!|": return BV((~(a.value | b.value)) & mask, a.width)
    if op == "!^": return BV((~(a.value ^ b.value)) & mask, a.width)
    if op == "min": return BV(min(a.value, b.value), a.width)
    if op == "max": return BV(max(a.value, b.value), a.width)
    raise ValueError(f"unsupported operator {op!r}")


def decide(text: str) -> bool:
    result = evaluate(parse(text))
    if not isinstance(result, bool):
        raise TypeError("top-level input is not a formula")
    return result


def self_test() -> None:
    cases = {
        "normalize all x:bv[2] (x:bv[2] = x:bv[2]).": True,
        "normalize ex x:bv[2] (x:bv[2] = {3}:bv[2]).": True,
        "normalize all x:bv[2] (x:bv[2] < (x:bv[2] + {1}:bv[2])).": False,
        "normalize all x:bv[2] ((x:bv[2] !& x:bv[2]) = x:bv[2]').": True,
        "normalize all x:bv[2] ((x:bv[2] !| {0}:bv[2]) = x:bv[2]').": True,
        "normalize all x:bv[2] (min(x:bv[2], {2}:bv[2]) <= {2}:bv[2]).": True,
        "normalize all x:bv[2] ((x:bv[2] = {3}:bv[2]) -> (ex y:bv[2] ((x:bv[2] !| (y:bv[2] & {2}:bv[2])) = (y:bv[2] + {3}:bv[2])))).": True,
    }
    for text, want in cases.items():
        got = decide(text)
        if got != want:
            raise AssertionError(f"oracle self-test failed: got {got}, want {want}: {text}")
    # Direct arithmetic cross-check over every width/value pair avoids relying
    # only on quantified parser tests.
    for w in range(1, 5):
        m = (1 << w) - 1
        for x, y in itertools.product(range(1 << w), repeat=2):
            assert BV(x + y, w).value == ((x + y) & m)
            assert BV(x - y, w).value == ((x - y) & m)
            assert BV(~(x | y), w).value == ((~(x | y)) & m)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="*")
    ap.add_argument("--self-test", action="store_true")
    ns = ap.parse_args()
    if ns.self_test:
        self_test()
        print("self-test: OK")
    for path in ns.files:
        with open(path, encoding="utf-8") as f:
            for lineno, line in enumerate(f, 1):
                if line.strip() and not line.lstrip().startswith("#"):
                    print(f"{path}:{lineno}: {'T' if decide(line) else 'F'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
