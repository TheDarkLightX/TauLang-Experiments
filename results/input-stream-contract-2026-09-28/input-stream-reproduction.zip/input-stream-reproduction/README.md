# File-input time-step contract example

Source: Tau fd536d56e00f12187cbed123c67a735a6964c660 and parser
5b14b6fde86f16dc52c4c0a953a8a1e53c88f95a. Recorded 2026-09-28 on
macOS 26.6.2 arm64, Clang 22.1.2 Release, default type pack.

From this directory, run each file in a fresh process:

```sh
tau --charvar=false --color=false --highlighting=false --benchmarks=false < output-lookback.tau
tau --charvar=false --color=false --highlighting=false --benchmarks=false < input-lookback.tau
```

The original build prints o1 values 0,a,b,a' in the first example and
0,b,a',b' in the second. The clause for o1 and the input file are identical.
The second example requests an earlier input for o2, which advances the file
one step earlier. The same observations were made with the printing-only
correction. This is a contract question, not an assertion that the current
request-driven interpretation is incorrect. It has not been rerun on newer
devel commits.

Both command inputs and complete original-build observations are included.
The checked binary hash is in observations.json. The source build
instructions are in the upstream README for the pinned version.
