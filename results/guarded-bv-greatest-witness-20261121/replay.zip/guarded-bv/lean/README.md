# Greatest witnesses for guarded Boolean-algebra quantifier elimination

Suppose x is a single unknown in a Boolean algebra and y and every coefficient u, v are given. Impose x ∧ y = 0 and a finite conjunction of clauses (x ∧ u = 0) ∨ (x ∧ v ≠ 0). Start from b = ¬y. If a remaining clause has b ∧ v = 0, replace b by b ∧ ¬u and remove that clause. If every remaining clause has b ∧ v ≠ 0, return b. Each removal consumes one clause. Even over an infinite algebra, a list of length m needs at most m removals. Executing the solver requires decidable equality and implementations of the Boolean operations.

## Kernel-checked results

- `preserve` proves that an update keeps every feasible x underneath the new bound.
- `stable_holds` proves that a stable bound satisfies every guard.
- `greatest` proves that with one unit of fuel per clause the computed bound is feasible and lies above every feasible x.
- `eliminate` proves that an additional upward-closed predicate P has a simultaneous solution exactly when P holds on the computed greatest bound.
- `nonzero` proves the equivalence specifically for x ≠ 0.

The kernel run reported the standard Lean axioms propext, Classical.choice and Quot.sound for all five declarations. The source introduces no axioms and contains no proof placeholders. The theorem covers the stated one-variable, mixed-sign fragment. Inputs from Tau’s parser or normalizer are not part of the formal interface.

## Replay

The source was checked with Lean 4.37.0-rc1 (0b77e12952ad39077d80d8bd6b66d601f225c321) and mathlib c47f9ad906c5ec32a953f99911b446cd26dcc123. From this directory, with elan or the matching Lean release installed, run the commands below.

```sh
lake update
lake exe cache get Mathlib.Order.BooleanAlgebra.Basic
lake env lean GuardedWitness.lean > observed.txt
diff -u kernel-receipt.txt observed.txt
```

The original check used the same pinned prebuilt mathlib import with Lean directly. The receipt records the axiom report. Source SHA-256 is `6f1d94237defc996f7dffa2bd85934c9330f0b7c01be4120f8e924aca6fab1e0`.
