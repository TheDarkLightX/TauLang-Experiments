"""Compare the unmodified native Tau decisions with independent finite ground truth."""
import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SCHEDULE = (
    (3, 6), (5, 10), (6, 9), (10, 12), (9, 3), (12, 5), (1, 4),
    (2, 8), (4, 1), (8, 2), (7, 12), (11, 5), (13, 10), (14, 3),
)
UPSTREAM = "ab7a13ed610ff6cfb8364dd2e509df74c9bdac6c"
WHEEL_EXTENSION = "e51c73b4b30b5c72595dcb43b1c3b04ebd32546dd5543e5aeec1dbb5f164d69c"
CLI_BINARY = "ab6777136a522144ce436aef759c044bc935d3858154bd9bfef31fc516ba990c"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bv(n):
    return "{" + str(n) + "}:bv[4]"


def matrix(n, y):
    factors = ["b:bv[4] != 0", f"(b & {bv(y)}) = 0"]
    for u, v in SCHEDULE[:n]:
        factors.append(f"(((b & {bv(u)}) = 0) || ((b & {bv(v)}) != 0))")
    return " && ".join(factors)


def six_factor(n):
    params = ["y"] + [v + str(i) for i in range(1, n+1) for v in ["x", "z"]]
    bind = " ".join("all " + p + ":sbf" for p in params)
    lhs = "ex b:sbf ((b & y:sbf) = 0 && " + " && ".join(
        f"((b & x{i}:sbf) != 0 || z{i}:sbf != 0)" for i in range(1, n+1)) + ")"
    rhs = " && ".join(f"(((y:sbf)' & x{i}:sbf) != 0 || z{i}:sbf != 0)" for i in range(1, n+1))
    return bind + " ((" + lhs + ") <-> (" + rhs + "))"


def greatest(width, y, rules):
    x = ((1 << width) - 1) ^ y
    trace = [x]
    while True:
        for u, v in rules:
            if x & v == 0:
                x &= ~u
        if x == trace[-1]:
            return x, trace
        trace.append(x)


def make_cases():
    cases = {}
    def put(name, verb, f, exp, xs=None):
        cases[name] = {"procedure": verb, "formula": f, "expected": exp}
        if xs is not None:
            cases[name]["finite_witnesses"] = xs

    for n in (2, 4, 6):
        put(f"issue152_{n}", "valid", six_factor(n), True)
    put("issue152_control", "valid",
        "all y:sbf all z:sbf all x:sbf all w:sbf ((ex b:sbf (((b & y:sbf) != 0 || z:sbf != 0) && ((b & x:sbf) != 0 || w:sbf != 0))) <-> ((y:sbf != 0 || z:sbf != 0) && (x:sbf != 0 || w:sbf != 0)))", True)
    put("issue152_wrong_expected_control", "valid", six_factor(2).replace("(y:sbf)'", "y:sbf"), False)
    put("issue151_seed_conflict", "unsat",
        "ex y:sbf ex b:sbf (b != 0 && (b & y) = 0 && (b & (y)') = 0)", True)
    put("issue151_seed_near_miss", "unsat",
        "ex y:sbf ex b:sbf (b != 0 && (b & y) = 0 && (b & y) = 0)", False)
    cascade = "(((b & {1}:bv[2]) = 0) || ((b & {2}:bv[2]) != 0))"
    second = "(((b & {2}:bv[2]) = 0) || ((b & {0}:bv[2]) != 0))"
    put("two_bit_cascade", "unsat", f"ex b:bv[2] (b != 0 && (b & {{0}}:bv[2]) = 0 && {cascade} && {second})", True)
    put("two_bit_remove_second", "sat", f"ex b:bv[2] (b != 0 && (b & {{0}}:bv[2]) = 0 && {cascade})", True)
    put("two_bit_disjoint_obligations", "valid",
        "all b:bv[2] ((((b & {1}:bv[2]) != 0) && ((b & {2}:bv[2]) != 0)) <-> b = {3}:bv[2])", True)
    zero, trace = greatest(2, 0, [(1, 2), (2, 0)])
    assert (zero, trace) == (0, [3, 1, 0])
    cases["two_bit_cascade"]["greatest_trace"] = trace
    for n in (4, 8, 12, 14):
        for y in range(16):
            witnesses = [x for x in range(16) if x != 0 and x & y == 0
                         and all((x & u) == 0 or (x & v) != 0 for u, v in SCHEDULE[:n])]
            m = matrix(n, y)
            put(f"mixed_n{n}_y{y}_exists", "sat", f"ex b:bv[4] ({m})", bool(witnesses), witnesses)
            explicit = " || ".join("b:bv[4] = " + bv(x) for x in witnesses) or "F"
            put(f"mixed_n{n}_y{y}_set", "valid", f"all b:bv[4] (({m}) <-> ({explicit}))", True, witnesses)
            g, trace = greatest(4, y, SCHEDULE[:n])
            assert (g in witnesses) == bool(witnesses) and all((x & g) == x for x in witnesses)
            q = f"all b:bv[4] (({m}) -> ((b & {bv(15 ^ g)}) = 0))"
            if g:
                q = f"({q}) && (ex b:bv[4] (b = {bv(g)} && {m}))"
            put(f"mixed_n{n}_y{y}_greatest", "valid", q, True)
            cases[f"mixed_n{n}_y{y}_greatest"]["greatest_trace"] = trace
    return cases


def run(args):
    cases = make_cases()
    if args.cli:
        cli = args.cli.resolve()
        if digest(cli) != CLI_BINARY and not args.allow_other_build:
            raise RuntimeError("Unexpected release CLI digest")
        build = {"kind": "unmodified release CLI" if digest(cli) == CLI_BINARY else "user-supplied CLI",
                 "executable_sha256": digest(cli),
                 "version": subprocess.check_output([cli, "--version"], text=True).strip()}
        def decide(verb, formula):
            result = subprocess.run([str(cli), "-S", "info", "-b", "false", "-c", "false",
                                     "-s", "false", "-e", f"{verb} {formula}"],
                                    stdin=subprocess.DEVNULL, capture_output=True, text=True,
                                    timeout=45, check=True)
            found = re.findall(r"^%\d+: ([TF])$", result.stdout, re.M)
            if result.stderr.strip() or len(found) != 1:
                raise RuntimeError((verb, formula, result.stdout, result.stderr))
            return found == ["T"]
    else:
        import tau
        ext, = Path(tau.__file__).parent.glob("tau.*.so")
        if digest(ext) != WHEEL_EXTENSION and not args.allow_other_build:
            raise RuntimeError("Unexpected exact-commit native extension digest")
        build = {"kind": "unmodified upstream native decision API", "source_commit": UPSTREAM,
                 "parser_commit": "7623ab8ddc19aeb33e1918342092a6d7092c40c4",
                 "ci_artifact_id": 14706228019, "extension_sha256": digest(ext)}
        if digest(ext) != WHEEL_EXTENSION:
            build = {"kind": "user-supplied native decision API", "extension_sha256": digest(ext)}
        def decide(verb, formula):
            r = getattr(tau, verb)(formula)
            if type(r.value) is not bool or r.report.errors or r.report.warnings:
                raise RuntimeError((verb, formula, repr(r), str(r.report)))
            return r.value

    for name, row in cases.items():
        row["observed"] = decide(row["procedure"], row["formula"])
        if row["observed"] != row["expected"]:
            raise AssertionError((name, row))
    result = {"build": build, "checks": len(cases), "schedule": SCHEDULE, "cases": cases}
    return json.dumps(result, indent=2) + "\n"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cli", type=Path, help="Official v0.8.5 Linux x86_64 executable")
    parser.add_argument("--allow-other-build", action="store_true",
                        help="Compare on a locally built runtime and identify it separately")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.write_text(run(args))
