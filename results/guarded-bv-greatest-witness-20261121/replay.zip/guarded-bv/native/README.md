# Native Tau replay

This directory contains the decision checks and the guarded frontend timing experiment for closed bitvector mask implications. All measurements used unmodified native Tau.

## Native decision evidence

The exact-head build is the Linux x86_64 native extension in the upstream GitHub Actions wheel, workflow run [44901174691](https://github.com/IDNI/tau-lang/actions/runs/44901174691), artifact [14706228019](https://api.github.com/repos/IDNI/tau-lang/actions/artifacts/14706228019). GitHub identifies its source as [ab7a13ed610ff6cfb8364dd2e509df74c9bdac6c](https://github.com/IDNI/tau-lang/tree/ab7a13ed610ff6cfb8364dd2e509df74c9bdac6c). Its parser submodule is 7623ab8ddc19aeb33e1918342092a6d7092c40c4. The 21 November 2026 run used CPython 3.14.10. The separate CLI cross-check used the public [v0.8.5 amd64 package](https://github.com/IDNI/tau-lang/releases/download/v0.8.5/tau-0.8.5_amd64.deb), whose executable reports 0.8.5 (a584081). The release tag points to 6ea436e8d3113a7d90635b9d06113e5bc506176c. The CQE header and parser submodule agree between the embedded CLI revision and the devel revision; the two native products have different build identities.

| Artifact | SHA-256 |
|---|---|
| CI wheel archive zip | 3fc2865e118e8f84eb33b57e9fc91193b1fcc0486d027f4d061e80c9726a1d43 |
| Wheel inside that archive | 8a48b1b93fff8a00a30bd5461a90ddb5c02fbb2409ad5062dd2702fe27034c04 |
| Unmodified CPython native extension | e51c73b4b30b5c72595dcb43b1c3b04ebd32546dd5543e5aeec1dbb5f164d69c |
| v0.8.5 release Debian package | 58cb9495df47699ecd6aab62691e9eccb8a29197239cceb72d569ff8215620b2 |
| v0.8.5 executable | ab6777136a522144ce436aef759c044bc935d3858154bd9bfef31fc516ba990c |

Each runtime agreed on 202 of 202 decisions, including the intentionally false claims. The tables in both receipt JSON files include every original formula, expected answer, observed answer, and the finite witness set when applicable.

* Six-, four-, and two-factor SBF instances from [issue 152](https://github.com/IDNI/tau-lang/issues/152) were universally equivalent to their hand-calculated forms. Its published negative-control workload also matched; a mutation replacing the complement of y by y invalidated the expected equivalence. These five decisions use symbolic SBF parameters.
* The [issue 151](https://github.com/IDNI/tau-lang/issues/151) seed asking for nonzero b with both b & y and b & complement(y) zero was unsatisfiable. Duplicating the first zero restriction restored satisfiability.
* Sixty-four *concrete* mixed-factor instances cover n = 4, 8, 12, 14 and the sixteen four-bit exclusions y. For each, the native solver checked existence, universal equivalence to the complete finite list of witnesses, and a universal upper bound with attainability whenever the proposed greatest witness was nonzero. For a proposed g=0, the zero upper bound plus the explicit nonzero requirement proves absence. The SAT y sets were {0,…,8}, {0,1,2}, {0}, and {0}, respectively. At n=14 and y=0 the only witness was 15.
* A two-bit cascade required repeated rule application, with complete-scan outputs 3, 1, 0. The original formula was unsatisfiable; dropping its second rule restored satisfiability. A separate formula requiring a nonzero intersection with each of two disjoint singleton masks admitted exactly b=3. These three decisions use fixed-width bitvectors.

The native validations check extensional truth and witness sets. They do not expose the engine's internal scheduling, branch or cache counts. Tau's standard SAT frontend may route bitvectors to a different backend from symbolic SBF.

## Run the decisions

In this directory, an authenticated GitHub CLI can fetch the CI artifact while it is retained. The same public artifact was retrieved in the recorded run via [nightly.link](https://nightly.link/IDNI/tau-lang/actions/artifacts/14706228019.zip); the archive digest was compared to the GitHub API's independently obtained digest. GitHub lists 19 February 2027 as the artifact expiry. A local build of the pinned source can be compared after that date with `--allow-other-build`, which records the build’s own digest.

```sh
gh run download 44901174691 --repo IDNI/tau-lang --name tau-wheel --dir upstream-wheel
python3.14 -m venv .venv
.venv/bin/pip install upstream-wheel/tau_nanobind-0.8.5-cp314-cp314-manylinux_2_39_x86_64.whl
.venv/bin/python native_replay.py --out exact-recomputed.json
cmp exact-head-receipt.json exact-recomputed.json
curl -fsSLO https://github.com/IDNI/tau-lang/releases/download/v0.8.5/tau-0.8.5_amd64.deb
dpkg-deb -x tau-0.8.5_amd64.deb tau-release
python3 native_replay.py --cli tau-release/usr/bin/tau --out cli-recomputed.json
cmp release-cli-receipt.json cli-recomputed.json
```

The three `.tau` files are standalone specifications. To replay them individually, read the source and pass it to `tau.unsat` for the two-bit cascade and `tau.valid` for the other two. Each call should return a result with `.value == True`.

## Guarded frontend benchmark

`frontend_bench.py` compares two ways to answer the same closed existence query. The first sends its original text to the pinned native `tau.sat`. The second receives the identical text and recognizes the complete canonical decimal bitvector formula: a nonzero witness b, an initial (b & y) = 0 restriction, and factors ((b & u) = 0 or (b & v) ≠ 0). It allows only the widths 2, 4, 16, and 32 and in-range constants. On a match it computes the greatest witness and sends the residual ground bitvector test to the same `tau.sat`. On a mismatch it sends the original input unchanged. The code is an experimental external frontend. Integration into the production parser or CQE core was not measured.

Each arm receives a fresh process and an empty process-local Tau solver cache, with no warmup. Six pairs alternate order (three each way), on one selected logical CPU of a shared AMD EPYC 9V74 host, Linux x86_64 kernel 6.18.57. Data and library pages can remain in the OS cache. The call timer starts before recognition and includes original/mutated input parsing and native checking as appropriate. Full worker time also includes Python startup, loading the native extension, and a worker-side SHA-256 provenance check. The outer trial loop is sequential. Raw observations and all input texts are in frontend-timings.json; timings will vary on replay.

| Input | Answer | Native call, ms | Guarded frontend call, ms | Full worker native → frontend, ms |
|---|---:|---:|---:|---:|
| Mixed, width 4, 14 factors, y=0 | SAT | 86.94 | 2.32 | 192.56 → 110.81 |
| Mixed, width 4, 14 factors, y=3 | UNSAT | 71.29 | 1.99 | 165.24 → 88.93 |
| Sixteen-bit cascade, 16 factors | UNSAT | 79.26 | 1.97 | 166.81 → 85.92 |
| Independent, width 32, 16 factors | SAT | 93.19 | 2.40 | 190.69 → 88.54 |
| Unsupported seed, 14 factors, original expression passed through | SAT | 72.96 | 69.84 | 164.21 → 158.16 |

All 60 decisions matched. The cascade took 17 scans including the final unchanged pass. In the passthrough control both arms send the same expression to the native solver; its sample difference gives a sense of timing variability. Sample medians represent these inputs on one host. They do not establish a performance gain in an upstream Tau algorithm. The witnessed decision is narrower than enumerating or counting derivations.

```sh
.venv/bin/python frontend_bench.py --out local-timings.json
```
