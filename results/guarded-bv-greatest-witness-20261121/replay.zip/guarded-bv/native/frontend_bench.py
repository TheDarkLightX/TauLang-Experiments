"""A guarded source-to-source existence fast path measured against stock Tau."""
import argparse
import hashlib
import json
import os
import platform
import re
import statistics
import subprocess
import sys
import time
from pathlib import Path

from native_replay import SCHEDULE, UPSTREAM, WHEEL_EXTENSION


def compile_grammar(w):
    c = r"\{([0-9]+)\}:bv\[" + str(w) + r"\]"
    start = re.compile(r"ex b:bv\[" + str(w) + r"\] \(b != 0 && \(b & " + c + r"\) = 0")
    factor = re.compile(r" && \(\(\(b & " + c + r"\) = 0\) \|\| \(\(b & " + c + r"\) != 0\)\)")
    return start, factor


GRAMMARS = {w: compile_grammar(w) for w in (2, 4, 16, 32)}


def reduce_existence(source):
    """Only this closed positive existential grammar, for complete input strings."""
    prefix = re.match(r"ex b:bv\[([0-9]+)\]", source)
    if not prefix or int(prefix[1]) not in GRAMMARS:
        return source, None
    width = int(prefix[1])
    start, factor = GRAMMARS[width]
    whole = start.match(source)
    if whole is None:
        return source, None
    pos = whole.end()
    limit = (1 << width) - 1
    y = int(whole[1])
    if y > limit:
        return source, None
    rules = []
    while m := factor.match(source, pos):
        u, v = int(m[1]), int(m[2])
        if max(u, v) > limit:
            return source, None
        rules.append((u, v))
        pos = m.end()
    if source[pos:] != ")" or not rules:
        return source, None
    x = limit ^ y
    passes = 0
    while True:
        old = x
        for u, v in rules:
            if not x & v:
                x &= ~u
        passes += 1
        if x == old:
            break
    # Input explicitly demands b != 0, so existence reduces to x != 0.
    # Use the same native decision API to decide the smaller closed expression.
    return f"{{{x}}}:bv[{width}] != {{0}}:bv[{width}]", passes


def source_text(width, y, rules):
    def c(i):
        return "{" + str(i) + "}:bv[" + str(width) + "]"
    factors = [f"b != 0", f"(b & {c(y)}) = 0"]
    factors += [f"(((b & {c(u)}) = 0) || ((b & {c(v)}) != 0))" for u, v in rules]
    return f"ex b:bv[{width}] (" + " && ".join(factors) + ")"


MIX = source_text(4, 0, SCHEDULE)
CASES = [
    ("mixed_14_sat", MIX, True),
    ("mixed_14_unsat", source_text(4, 3, SCHEDULE), False),
    ("cascade_16_unsat", source_text(16, 0,
         [(1 << i, 1 << (i + 1)) for i in range(15)] + [(1 << 15, 0)]), False),
    ("independent_16_sat", source_text(32, 0, [(1 << (2*i), 1 << (2*i+1)) for i in range(16)]), True),
    ("out_of_grammar_14", MIX.replace("b != 0", "b = 0", 1), True),
]


def worker():
    import tau
    arm, source = json.load(sys.stdin)
    # Native import and provenance checks are outside the in-process wall interval.
    ext, = Path(tau.__file__).parent.glob("tau.*.so")
    assert hashlib.sha256(ext.read_bytes()).hexdigest() == WHEEL_EXTENSION
    t0 = time.perf_counter_ns()
    txt, passes = reduce_existence(source) if arm == "frontend" else (source, None)
    r = tau.sat(txt)
    ts = time.perf_counter_ns() - t0
    if type(r.value) is not bool or r.report.errors or r.report.warnings:
        raise RuntimeError((r.value, str(r.report)))
    print(json.dumps([ts, r.value, passes]))


def main(path):
    cpu = sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else []
    if cpu:
        os.sched_setaffinity(0, [cpu[0]])
    report = {"source_commit": UPSTREAM, "native_extension_sha256": WHEEL_EXTENSION,
              "machine": platform.machine(), "kernel": platform.release(), "python": sys.version.split()[0],
              "cpu_model": next((r.split(":", 1)[1].strip() for r in Path("/proc/cpuinfo").read_text().splitlines()
                                  if r.startswith("model name")), None),
              "logical_cpu": cpu[0] if cpu else None,
              "pairs": 6, "mode": "fresh process per solve, native import excluded from measured call time",
              "cases": {}}
    for name, source, truth in CASES:
        case = {"input": source, "expected": truth, "observations": [], "median_ms": {}}
        report["cases"][name] = case
        for trial in range(6):
            for arm in (("native", "frontend") if trial % 2 == 0 else ("frontend", "native")):
                tick = time.perf_counter_ns()
                p = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker"],
                    input=json.dumps([arm, source]), text=True, capture_output=True, timeout=20, check=True)
                elapsed = time.perf_counter_ns() - tick
                if p.stderr:
                    raise RuntimeError(p.stderr)
                called, verdict, passes = json.loads(p.stdout)
                assert verdict is truth
                assert (passes is not None) == (arm == "frontend" and name != "out_of_grammar_14")
                case["observations"].append({"pair": trial+1, "arm": arm, "call_ns": called,
                    "process_ns": elapsed, "observed": verdict, "passes": passes})
        for arm in ("native", "frontend"):
            rows = [r for r in case["observations"] if r["arm"] == arm]
            case["median_ms"][arm] = {m: statistics.median(r[m+"_ns"] for r in rows)/1e6
                                       for m in ("call", "process")}
        path.write_text(json.dumps(report, indent=2)+"\n")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path)
    p.add_argument("--worker", action="store_true")
    args = p.parse_args()
    if args.worker:
        worker()
    else:
        main(args.out)
