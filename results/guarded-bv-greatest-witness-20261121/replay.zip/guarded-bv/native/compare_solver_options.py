"""Sensitivity to native settings, input size, and repeated identical submissions."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time

from frontend_bench import SCHEDULE, UPSTREAM, WHEEL_EXTENSION, reduce_existence, source_text


CONFIGS = {
    "native_default": {},
    "guarded_default": {},
    "native_preprocessing_width32": {"preprocessing": "true", "bv-bitblast-max-width": "32"},
    "native_bdd_off_qf_on": {"bv-bitblast-max-nodes": "0", "bv-bitblast-qf-max-nodes": "0"},
}
OPTIONS = ["preprocessing", "block-max-splits", "bv-quantifier-free-decision",
           "bv-bitblast-max-width", "bv-bitblast-max-nodes", "bv-bitblast-qf-max-nodes",
           "bv-blasting", "bv-case-split", "bv-definitional-elimination", "bv-widening"]
SMALL = source_text(4, 0, SCHEDULE[:4])
CASES = {"one_sat": (source_text(4, 0, SCHEDULE[:1]), True),
         "four_sat": (SMALL, True),
         "four_fallback": (SMALL.replace("b != 0", "b = 0", 1), True),
         "fourteen_sat": (source_text(4, 0, SCHEDULE), True),
         "wide16_independent": (source_text(32, 0, [(1 << (2*i), 1 << (2*i+1)) for i in range(16)]), True)}


def worker():
    import tau
    name, source = json.load(sys.stdin)
    ext, = Path(tau.__file__).parent.glob("tau.*.so")
    assert hashlib.sha256(ext.read_bytes()).hexdigest() == WHEEL_EXTENSION
    for k, v in CONFIGS[name].items():
        assert tau.set_option(k, v).value == v
    options = {k: tau.get_option(k).value for k in OPTIONS}
    times = []
    answers = []
    for _ in range(5):
        start = time.perf_counter_ns()
        selected = reduce_existence(source)[0] if name == "guarded_default" else source
        r = tau.sat(selected)
        elapsed = time.perf_counter_ns() - start
        assert type(r.value) == bool and not r.report.errors and not r.report.warnings
        times.append(elapsed)
        answers.append(r.value)
    print(json.dumps([options, times, answers]))


def main(out):
    cpu = min(os.sched_getaffinity(0))
    os.sched_setaffinity(0, [cpu])
    data = {"source_commit": UPSTREAM, "extension_sha256": WHEEL_EXTENSION,
            "kernel": platform.release(), "cpu": cpu, "python": sys.version.split()[0],
            "pairs": 6, "native_sat_signature": "sat(spec: str)",
            "method": "A fresh process per arm and block. First cold call and four immediate re-submissions. Reverse arm order in alternating blocks.",
            "settings": {}, "cases": {}}
    for name, (source, expected) in CASES.items():
        row = {"source": source, "expected": expected, "results": {}, "median_ms": {}}
        data["cases"][name] = row
        for block in range(6):
            arms = list(CONFIGS)
            for arm in arms if block % 2 == 0 else reversed(arms):
                p = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker"],
                    input=json.dumps([arm, source]), text=True, capture_output=True, check=True, timeout=30)
                if p.stderr:
                    raise RuntimeError(p.stderr)
                settings, times, answers = json.loads(p.stdout)
                assert answers == [expected]*5
                assert data["settings"].setdefault(arm, settings) == settings
                row["results"].setdefault(arm, []).append(
                    {"block": block+1, "cold_ns": times[0], "warm_ns": times[1:], "verdicts": answers})
        for arm, samples in row["results"].items():
            row["median_ms"][arm] = {
                "cold": statistics.median(s["cold_ns"] for s in samples)/1e6,
                "warm": statistics.median(statistics.median(s["warm_ns"]) for s in samples)/1e6}
        out.write_text(json.dumps(data, indent=2)+"\n")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path)
    p.add_argument("--worker", action="store_true")
    args = p.parse_args()
    if args.worker:
        worker()
    else:
        main(args.out)
