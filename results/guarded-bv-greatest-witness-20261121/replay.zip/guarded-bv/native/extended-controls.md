# Tau frontend controls

The released 0.8.5 CLI and the exact devel native wheel already offer bounded bit-level BDD decision and a quantifier-free decision path. Issue 184 describes earlier experiments on a specific historical patch. The November comparison used the current upstream implementation. The source and live option readback establish which paths are enabled or available. They do not trace which path was actually taken for each call.

On the pinned wheel, the defaults were quantifier-free decision on, general BDD node budget 1,048,576, quantifier-free BDD node budget 16,384, width limit 16, widening off, preprocessing off, and block split limit 0 (unlimited). Predicate blasting was enabled subject to the separate global preprocessing switch. Fresh processes read back and recorded these settings for each trial. Selecting preprocessing and a width of 32 was an additional native comparison. A fourth arm set both decision BDD node budgets to zero while leaving quantifier-free decision on. The bundled Python sat function takes a string and reparses it on every call.

## Existing solver options, small inputs and repeated calls

Six independent workers per arm, alternating forward/reverse arm order by block. First call follows import and option readback. Each worker immediately resubmits its same input four times. Warm numbers are the median across workers of each worker’s four-repeat median. Units are elapsed milliseconds for the call. Coverage was 5 expressions × 4 configurations × 6 workers × 5 calls = 600 correct decisions. The two generic option settings are tested in the native arm. The guarded arm uses the standard defaults.

| Input | Native default cold / warm | Guarded default cold / warm | Native preprocessing + width 32 cold / warm | Native BDD off, QF on cold / warm |
|---|---:|---:|---:|---:|
| one_sat | 9.22 / 8.24 | 2.05 / 1.30 | 9.11 / 8.33 | 10.76 / 8.38 |
| four_sat | 22.14 / 20.91 | 1.95 / 1.26 | 22.65 / 20.88 | 24.47 / 21.36 |
| four_fallback | 22.91 / 21.88 | 24.63 / 25.01 | 24.02 / 22.25 | 25.18 / 20.89 |
| fourteen_sat | 72.41 / 69.76 | 1.88 / 1.31 | 69.64 / 68.16 | 70.56 / 69.03 |
| wide16_independent | 90.35 / 84.27 | 2.35 / 1.57 | 85.45 / 81.01 | 87.35 / 81.36 |

The four-factor unsupported control ran slower in the guarded sample. The original input was passed through unchanged, and variation exceeded what could be attributed to the spelling check alone. Warm repeats still include full text parsing. The width-32 case exceeds the default bitblast width; the widened native setting admits it within that limit. None of these measurements is a BDD or cvc5 microbenchmark.

## Type inspection followed by a decision on a stored expression

The public v0.8.5 Linux CLI embeds a584081 and has the same REPL inspection and CQE header source as the devel pin. Each fresh CLI received `whatis SOURCE`, which parses, applies definitions and type information, rebuilds the expression, displays its type and normalized spelling in the REPL, then stores the resulting node in history slot %1. The guarded arm recognizes the original bytes and computes its smaller ground expression inside the first timer. A second command, `sat %1`, decides the stored formula. Times include those command/response round trips, rendering and pipe I/O. The tiny second command is parsed. The measurement isolates neither parsing nor the solver in isolation. No raw source was resubmitted for the second step. The session start and shutdown were outside the timers. Six alternating original/guarded pairs per case produced 84 verified decisions.

| Input | Type-inspect/store original / guarded (ms) | Decide stored original / guarded (ms) |
|---|---:|---:|
| one_sat | 9.02 / 2.67 | 1.37 / 1.19 |
| four_sat | 21.10 / 2.75 | 1.76 / 1.22 |
| mixed_14_sat | 62.02 / 2.76 | 2.92 / 1.17 |
| mixed_14_unsat | 59.66 / 2.72 | 2.83 / 1.23 |
| cascade_16_unsat | 70.44 / 2.66 | 3.02 / 1.20 |
| independent_16_sat | 73.48 / 2.81 | 7.97 / 1.24 |
| out_of_grammar_14 | 59.92 / 60.33 | 2.71 / 2.83 |

For the 14-factor satisfiable case the median difference for deciding the stored formulas is 1.75 ms. The much larger difference appears while preparing the expression in this two-command workflow. The residual ground expression frequently simplifies to a truth constant at inspection. An optimization implemented after ordinary parsing would incur some of the initial processing cost on the original text. A production performance claim would require timing at its actual native integration point.

Both scripts import frontend_bench.py and native_replay.py from the adjacent directory. The README describes acquiring the pinned wheel/CLI. Replay with:

```sh
.venv/bin/python compare_solver_options.py --out new-options.json
python3 typed_repl_control.py --cli tau-release/usr/bin/tau --out new-typed-repl.json
```

Sources: [BV option definitions](https://github.com/IDNI/tau-lang/blob/ab7a13ed610ff6cfb8364dd2e509df74c9bdac6c/src/boolean_algebras/bv/bv_options.h#L64), [native decision implementation](https://github.com/IDNI/tau-lang/blob/ab7a13ed610ff6cfb8364dd2e509df74c9bdac6c/src/boolean_algebras/bv/bv_ba_solver.tmpl.h#L792), [nanobind string decision entry](https://github.com/IDNI/tau-lang/blob/ab7a13ed610ff6cfb8364dd2e509df74c9bdac6c/bindings/python/nanobind/tau_nanobind.cpp#L816), [REPL type inspection](https://github.com/IDNI/tau-lang/blob/ab7a13ed610ff6cfb8364dd2e509df74c9bdac6c/src/repl_evaluator.tmpl.h#L725), [retrieval and application of history arguments](https://github.com/IDNI/tau-lang/blob/ab7a13ed610ff6cfb8364dd2e509df74c9bdac6c/src/repl_evaluator.tmpl.h#L355), and [historical issue 184](https://github.com/IDNI/tau-lang/issues/184).
