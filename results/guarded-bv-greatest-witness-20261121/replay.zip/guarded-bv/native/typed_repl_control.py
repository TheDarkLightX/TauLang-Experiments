"""Time Tau's type-inspection/history stage separately from its decision on %1."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import select
import statistics
import subprocess
import time

from frontend_bench import CASES, SCHEDULE, reduce_existence, source_text
from native_replay import CLI_BINARY


PROMPT = b"tau> "


def read_prompt(proc):
    b = bytearray()
    deadline = time.monotonic() + 30
    while not b.endswith(PROMPT):
        remaining = max(0, deadline - time.monotonic())
        if not select.select([proc.stdout], [], [], remaining)[0]:
            raise TimeoutError(bytes(b))
        chunk = os.read(proc.stdout.fileno(), 65536)
        if not chunk:
            raise RuntimeError(bytes(b))
        b.extend(chunk)
    return bytes(b)


def submit(proc, command):
    proc.stdin.write((command + "\n").encode())
    proc.stdin.flush()
    return read_prompt(proc)


def trial(cli, guarded, source, truth):
    with subprocess.Popen([cli, "-X", "true", "-S", "info", "-b", "false", "-c", "false",
                           "-s", "false"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT) as p:
        try:
            read_prompt(p)
            tick = time.perf_counter_ns()
            txt = reduce_existence(source)[0] if guarded else source
            inspected = submit(p, "whatis " + txt)
            split = time.perf_counter_ns()
            decided = submit(p, "sat %1")
            stop = time.perf_counter_ns()
            assert b"node type: wff" in inspected and re.search(rb"(?m)^%1:", inspected)
            got = re.findall(rb"(?m)^%\d+: ([TF])$", decided)
            assert got == ([b"T"] if truth else [b"F"]), decided
            return {"inspect_store_ns": split-tick, "decide_stored_ns": stop-split,
                    "both_ns": stop-tick, "inspection_output_bytes": len(inspected),
                    "decision_output_bytes": len(decided), "observed": truth}
        finally:
            p.stdin.close()
            p.wait(timeout=5)


def main(cli, path):
    if hashlib.sha256(cli.read_bytes()).hexdigest() != CLI_BINARY:
        raise RuntimeError("Unexpected release CLI digest")
    assert "(a584081)" in subprocess.check_output([cli, "--version"], text=True)
    cpu = min(os.sched_getaffinity(0))
    os.sched_setaffinity(0, [cpu])
    cases = [("one_sat", source_text(4, 0, SCHEDULE[:1]), True),
             ("four_sat", source_text(4, 0, SCHEDULE[:4]), True), *CASES]
    d = {"executable_sha256": CLI_BINARY, "release": "0.8.5 (a584081)", "cpu": cpu,
         "kernel": platform.release(), "pairs": 6, "cases": {}}
    for name, source, truth in cases:
        row = {"input": source, "expected": truth, "trials": [], "median_ms": {}}
        d["cases"][name] = row
        for i in range(6):
            for guarded in ((False, True) if i%2 == 0 else (True, False)):
                row["trials"].append({"block": i+1, "frontend": guarded,
                                      **trial(str(cli), guarded, source, truth)})
        for guarded in (False, True):
            samples = [s for s in row["trials"] if s["frontend"] == guarded]
            row["median_ms"]["guarded" if guarded else "original"] = {
                k.removesuffix("_ns"): statistics.median(s[k] for s in samples)/1e6
                for k in ("inspect_store_ns", "decide_stored_ns", "both_ns")}
        path.write_text(json.dumps(d, indent=2)+"\n")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--cli", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    main(args.cli.resolve(), args.out)
