"""Exhaust the prototype's two-bit rule schedules of lengths one through three."""
from itertools import product
from collections import Counter
import json
from frontend_bench import reduce_existence, source_text

def main():
    domain=range(4)
    counts=Counter()
    for n in (1,2,3):
        for y in domain:
            for rules in product(product(domain,domain),repeat=n):
                text=source_text(2,y,rules)
                reduced,passes=reduce_existence(text)
                witnesses=[x for x in domain if x!=0 and (x & y)==0 and
                           all((x & u)==0 or (x & v)!=0 for u,v in rules)]
                greatest=0
                for w in witnesses:
                    greatest |= w
                expected = f"{{{greatest}}}:bv[2] != {{0}}:bv[2]"
                assert reduced==expected and passes is not None and (not witnesses or greatest in witnesses)
                counts[n]+=1
    s=source_text(2,0,[(1,2)])
    outside=[s.replace('ex ','all ',1),s+' && F',s.replace('b != 0','b = 0',1),
             s.replace('{1}:bv[2]','{1}:bv[4]'),s.replace('{1}:bv[2]','{5}:bv[2]'),
             s.replace('b & {2}',"(b)' & {2}"),s.replace('{2}:bv[2]','v:bv[2]'),
             s.replace(') || (',') && ('),s.replace('ex b:','ex x:')]
    assert all(reduce_existence(q)==(q,None) for q in outside)
    print(json.dumps({"recognized_schedules_by_length":counts,"total":sum(counts.values()),
                      "out_of_fragment_string_fallbacks":len(outside)},indent=2))
if __name__ == '__main__':
    main()
