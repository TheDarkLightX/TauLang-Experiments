# Greatest witnesses for concrete bit vectors

`guarded_bv.hpp` is a standalone C++17 implementation of the one-variable guarded Boolean-algebra rule for bit vectors of width 1 through 64. It uses the C++ standard library. Pass the concrete guard mask y and a list of concrete coefficient pairs (u, v). The function returns the greatest feasible x under bitwise inclusion for the formula

    (x & y) = 0 AND, for each pair (u, v), ((x & u) = 0 OR (x & v) != 0).

Start at b = complement(y) in the declared width. If b avoids v, every feasible x below b also avoids v. That clause requires x to avoid u. Clear u from b and drop the discharged clause. If no positive arm is dead, b satisfies the remaining clauses. The loop removes at most one entry per iteration and at most m entries in total. Rescanning and erasing can take quadratic time in m.

`Result::greatest` exposes the witness. `Result::admits_nonzero()` additionally tests the existential requirement x != 0. The positive fragment always admits x = 0 when no nonzero condition is imposed. A disengaged optional means the caller should use its existing path.

A Tau integration must establish that the bound variable and type agree in every term and that all coefficients have concrete values. This example takes normalized data through a typed interface. Mixed widths, malformed bit patterns and unsupported polarities return a disengaged optional. It supplies no parser or upstream normalization patch.

## Replay

From this directory:

```sh
c++ -std=c++17 -O2 -Wall -Wextra -Wpedantic -Werror replay.cpp -o replay
./replay > observed.txt
diff -u receipt.txt observed.txt
```

The original check used Debian g++ 14.2.0 with undefined-behavior sanitization as well. For each ordered list of one to three coefficient pairs of width two, the oracle checks every y and every x directly against the original formula. Across all lists this is 17,472 formula instances and 69,888 concrete assignments. It verifies that the returned value is feasible and equals the bitwise union of every feasible x. The checks also cover empty inputs at width 64, the high bit, reverse-order cascading reductions and malformed or unsupported inputs.

The complemented-variable anti-control uses ((x & 1) = 0 OR ((complement x) & 2) != 0). At width two with y = 0, x = 1 and x = 2 each satisfy it and their join 3 fails. Its correct status in this specialized solver is deferred.
