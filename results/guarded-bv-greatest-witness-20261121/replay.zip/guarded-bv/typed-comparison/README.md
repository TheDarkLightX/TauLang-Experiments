# Native decision-kernel comparison

Both paths receive the same already-constructed cvc5 matrix with one free constant representing the dropped existential binder. The baseline calls Tau's `cvc5_bitblast_sat` with the pinned defaults for a quantifier-free matrix, width limit 16 and node limit 16,384. The candidate calls `bv_guarded_witness_sat` with an unlimited deadline, then calls that same BDD routine if recognition declines. All BDD calls returned a Boolean decision. Independent scalar enumeration over all values of the bound variable supplies the reference verdict for every formula. The benchmark checks every measured return value.

## Replay

Use a checkout of `IDNI/tau-lang` at `ab7a13ed610ff6cfb8364dd2e509df74c9bdac6c` with the candidate patch applied and the cvc5 1.3.1 development headers and shared library. Set `TAU_SRC` to the checkout root and `CVC5_PREFIX` to the installation containing `include/cvc5/cvc5.h` and `lib/libcvc5.so`. From this directory, run

```sh
g++ -std=c++20 -O2 -DNDEBUG -I"$TAU_SRC/src" -I"$CVC5_PREFIX/include" \
  compare.cpp -L"$CVC5_PREFIX/lib" -Wl,-rpath,"$CVC5_PREFIX/lib" -lcvc5 -o compare
./compare > local.csv
python3 summarize.py local.csv
```

The recorded run used GCC 14.2.0 on Debian 13 x86-64, an AMD EPYC 9V74, and the cvc5 1.3.1 shipped with Tau's official Linux SDK. The process ran on a shared host without CPU pinning or frequency control. The candidate header SHA-256 was `0a16cf784c3603d12ef2f67562ea34c2741f917cee6a4ecbe5f9a0e11e5745a4`. The upstream BDD header SHA-256 was `4c42060462d55cde43f131eae913ab7201f8c46a58d8625293f957d109bac01a`.

## Design and scope

Six designed corpora vary the number of factors, word width and traversal position of an unsupported expression. The seed is x ≠ 0 and (x & y) = 0. Within a corpus, y covers every word of its width. The single-guard corpus uses masks 3→6, and the four- and fourteen-guard corpora use the schedule in `compare.cpp`. The eight-bit cascade requires each bit present below the top bit to have the next higher bit present. Two controls complement the bound variable in one consequent of the fourteen-guard corpus. In the left-associated binary tree the stack examines this unsupported literal early or late. The harness verifies admission or fallback explicitly for each formula, independent of its final truth value.

Each method received two untimed corpus sweeps, followed by twelve measured blocks of 512 queries per method per corpus. The experiment reuses the term manager and input expressions. It shuffles inputs with a fixed seed per block, uses the same permutation for both methods, and alternates which method runs first. The measured interval includes the decision call(s) and a verdict comparison. Construction of the term DAG, scalar oracle, source parsing, binder translation, feature-gate entry checks, caches outside these two kernels, and surrounding CLI/API work lie outside the timed interval. The benchmark addresses isolated decision costs on these inputs. It does not estimate production hit rates or an application speedup.

| Corpus | Formulas | BDD μs/query | Guard then BDD μs/query | Median paired BDD ÷ candidate | Blocks won |
|---|---:|---:|---:|---:|---:|
| One guard, 4 bits | 16 | 13.63 | 3.36 | 3.99 | 12/12 |
| Four guards, 4 bits | 16 | 33.64 | 8.30 | 4.02 | 12/12 |
| Fourteen guards, 4 bits | 16 | 81.08 | 26.24 | 3.23 | 12/12 |
| Seven-step cascade, 8 bits | 256 | 48.34 | 13.66 | 3.48 | 12/12 |
| Unsupported complement encountered early | 16 | 79.49 | 80.71 | 0.99 | 3/12 |
| Unsupported complement encountered late | 16 | 78.07 | 103.30 | 0.76 | 0/12 |

Each μs value is the median time per decision within a method, calculated from the twelve block averages. The paired ratio is the median of the twelve within-block ratios. The late decline added about 32% over the existing BDD decision on this corpus. In `raw.csv`, `sat_instances` and `admitted_instances` count distinct formulas in the corpus and repeat per timing row. There are 73,728 timed queries in total (six corpora × twelve blocks × two methods × 512). `summary.json` includes every paired ratio range. Input selection and timings are specific to this benchmark.
