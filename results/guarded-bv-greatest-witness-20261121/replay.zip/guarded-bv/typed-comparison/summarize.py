"""Summarize paired native decision-kernel samples. Python 3.9 or later."""
import csv
import json
import sys
from collections import defaultdict
from statistics import median


def summarize(path):
    groups = defaultdict(list)
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            groups[row["corpus"]].append(row)
    out = {}
    for name, rows in groups.items():
        by_method = defaultdict(dict)
        for r in rows:
            by_method[r["method"]][int(r["block"])] = int(r["ns_total"]) / int(r["queries"])
        base, guard = by_method["bdd"], by_method["guard-then-bdd"]
        assert set(base) == set(guard) == set(range(12))
        ratios = [base[i] / guard[i] for i in range(12)]
        out[name] = {
            "unique_formulas": int(rows[0]["instances"]),
            "satisfiable": int(rows[0]["sat_instances"]),
            "admitted": int(rows[0]["admitted_instances"]),
            "queries_per_method": sum(int(r["queries"]) for r in rows if r["method"] == "bdd"),
            "median_bdd_ns_per_query": round(median(base.values()), 1),
            "median_guard_then_bdd_ns_per_query": round(median(guard.values()), 1),
            "median_paired_bdd_over_candidate": round(median(ratios), 4),
            "paired_ratio_min": round(min(ratios), 4),
            "paired_ratio_max": round(max(ratios), 4),
            "candidate_faster_blocks": sum(x > 1 for x in ratios),
        }
    return out


if __name__ == "__main__":
    print(json.dumps(summarize(sys.argv[1]), indent=2))
