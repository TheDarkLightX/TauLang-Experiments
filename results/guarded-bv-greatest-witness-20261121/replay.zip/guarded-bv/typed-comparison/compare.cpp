// Microbenchmark two native Tau decision paths on the same cvc5 terms.
#include "backends/cvc5/cvc5_bitblast.h"
#include "boolean_algebras/bv/heuristics/bv_guarded_witness.h"
#include <chrono>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>

using namespace idni::tau_lang;
using namespace cvc5;
using clock_type = std::chrono::steady_clock;

enum class polarity { normal, complement };
struct factor { unsigned u, v; polarity sign = polarity::normal; };
struct corpus {
	std::string name;
	unsigned width;
	std::vector<factor> rules;
	bool admitted;
};
struct sample { Term variable, matrix; bool expected; };

std::vector<sample> make_samples(TermManager& tm, const corpus& spec) {
	const unsigned stop = 1u << spec.width;
	const auto x = tm.mkConst(tm.mkBitVectorSort(spec.width), "x");
	const auto z = tm.mkBitVector(spec.width, 0);
	const auto nx = tm.mkTerm(Kind::BITVECTOR_NOT, {x});
	const auto nonzero = tm.mkTerm(Kind::DISTINCT, {x, z});
	auto masked = [&](const Term& term, unsigned coefficient, Kind kind) {
		const auto c = tm.mkBitVector(spec.width, coefficient);
		const auto intersection = tm.mkTerm(Kind::BITVECTOR_AND, {term, c});
		return tm.mkTerm(kind, {intersection, z});
	};
	std::vector<sample> samples;
	for (unsigned y = 0; y < stop; ++y) {
		auto f = tm.mkTerm(Kind::AND, {nonzero, masked(x, y, Kind::EQUAL)});
		for (const auto& [u, v, sign] : spec.rules) {
			const auto& term = sign == polarity::normal ? x : nx;
			const auto alternative = tm.mkTerm(Kind::OR,
				{masked(x, u, Kind::EQUAL), masked(term, v, Kind::DISTINCT)});
			f = tm.mkTerm(Kind::AND, {f, alternative});
		}
		bool expected = false;
		for (unsigned witness = 1; witness < stop; ++witness) {
			if (witness & y) continue;
			bool valid = true;
			for (const auto& [u, v, sign] : spec.rules) {
				const auto term = sign == polarity::normal ? witness : ~witness;
				if ((witness & u) != 0 && (term & v) == 0) valid = false;
			}
			if (valid) { expected = true; break; }
		}
		samples.push_back({x, f, expected});
	}
	return samples;
}

// Upstream's defaults for the quantifier-free matrix path at the pinned revision.
std::optional<bool> bdd(const Term& f) { return cvc5_bitblast_sat(f, 16, 16384); }

void run(const std::vector<sample>& samples, const std::vector<size_t>& order,
		bool try_guard, size_t repeats) {
	const auto unlimited = clock_type::time_point::max();
	for (size_t i = 0; i < repeats; ++i) for (size_t j : order) {
		const auto& s = samples[j];
		std::optional<bool> answer;
		if (try_guard) answer = bv_guarded_witness_sat(s.matrix, s.variable, unlimited);
		if (!answer.has_value()) answer = bdd(s.matrix);
		if (!answer.has_value() || *answer != s.expected)
			throw std::logic_error("incorrect or undecided verdict");
	}
}

int main() {
	TermManager tm;
	const std::vector<factor> mixed{{3,6},{5,10},{6,9},{10,12},{9,3},{12,5},
		{1,4},{2,8},{4,1},{8,2},{7,12},{11,5},{13,10},{14,3}};
	auto early = mixed, late = mixed;
	early.back().sign = polarity::complement;  // visited first by the stack
	late.front().sign = polarity::complement;
	const std::vector<corpus> corpora{
		{"one-guard", 4, {{3,6}}, true},
		{"mixed-four", 4, {mixed.begin(), mixed.begin()+4}, true},
		{"mixed-fourteen", 4, mixed, true},
		{"cascade", 8, {{1,2},{2,4},{4,8},{8,16},{16,32},{32,64},{64,128}}, true},
		{"decline-early", 4, early, false}, {"decline-late", 4, late, false}};
	std::mt19937 rng(182151152);
	std::cout << "corpus,block,position,method,queries,sat_instances,admitted_instances,instances,ns_total\n";
	for (const auto& spec : corpora) {
		const auto samples = make_samples(tm, spec);
		size_t sat = 0, admitted = 0;
		std::vector<size_t> order(samples.size());
		std::iota(order.begin(), order.end(), size_t{0});
		for (const auto& s : samples) {
			const auto answer = bv_guarded_witness_sat(s.matrix, s.variable, clock_type::time_point::max());
			if (answer.has_value() != spec.admitted || (answer && *answer != s.expected))
				throw std::logic_error("unexpected guard admission or verdict");
			sat += s.expected;
			admitted += answer.has_value();
		}
		// Comparable sample sizes across the 16- and 256-instance corpora.
		const size_t repeats = 512 / samples.size();
		for (bool guard : {false, true}) run(samples, order, guard, 2);
		for (int block = 0; block < 12; ++block) {
			std::shuffle(order.begin(), order.end(), rng);
			for (int position = 0; position < 2; ++position) {
				const bool guard = (block+position) % 2 != 0;
				const auto start = clock_type::now();
				run(samples, order, guard, repeats);
				const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
					clock_type::now() - start).count();
				std::cout << spec.name << ',' << block << ',' << position << ','
					<< (guard ? "guard-then-bdd" : "bdd") << ',' << samples.size()*repeats << ','
					<< sat << ',' << admitted << ',' << samples.size() << ',' << ns << '\n';
			}
		}
	}
}
