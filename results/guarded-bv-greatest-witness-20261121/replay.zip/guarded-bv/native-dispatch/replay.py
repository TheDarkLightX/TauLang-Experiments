"""Verify numerical answers and path counters against the tabulated public expectations."""
import argparse
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument("driver", type=Path)
p.add_argument("--baseline", action="store_true")
args = p.parse_args()
rows = json.loads((root / "cases.json").read_text())
hits = 0
for name, case in rows.items():
    result = subprocess.run([str(args.driver.resolve())], input=case["formula"] + "\n",
                            text=True, capture_output=True, check=True, timeout=30)
    verdict, delta, _, _ = result.stdout.strip().split()
    if verdict != case["expected"] or int(delta) != (0 if args.baseline else case["expected_hits"]):
        raise SystemExit(f"{name}: {result.stdout.strip()}")
    hits += int(delta)
print(f"{len(rows)} native decisions matched; {hits} guarded-path successes.")
