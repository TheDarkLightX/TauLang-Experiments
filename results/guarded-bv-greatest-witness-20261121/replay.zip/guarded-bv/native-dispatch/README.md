# Parsed native decision-path replay

The driver reads a Tau formula, calls the upstream parser with the WFF start rule, and passes the parsed tree to `bv_formula_sat_status<tau_pack::node_t>`. It reads the patched implementation's success counter around that call. A new process runs each case, so answers from an earlier formula cannot satisfy a counter check. The JSON contains every input, expected decision and path, and observed values. This is a focused native check. It does not require building the CLI or the full upstream test matrix.

The reference implementation in this supplement used the ab7a13ed610ff6cfb8364dd2e509df74c9bdac6c Tau tree, its 7623ab8ddc19aeb33e1918342092a6d7092c40c4 parser submodule, the public v0.8.5 Linux x86_64 SDK, and Clang 19.1.7 with GCC 14's C++ standard library. The SDK provides the prebuilt default pack, generated headers and dependency libraries. The solver header and its new helper compile from the patched source directory. This is a mixed source/SDK build; a source-only full upstream Release build is a different test.

* 64 four-bit cases cover 4, 8, 12 and 14 clauses across 16 initial exclusions. A scalar enumeration over all sixteen potential witnesses determined each expected Boolean. All 64 hit the guarded route.
* At widths 3, 8, and 16, changing a consequent toggles between SAT and UNSAT. All six hit. At widths 17, 32, 64, and 65, the eight corresponding inputs have the same verdicts while the default width cap of 16 selects the fallback.
* One universal, one complemented term, and one free coefficient select the fallback. All three have the expected verdict. In all, the candidate answered 81/81 correctly and the guard fired 70 times.

## Reproduce

Use Linux x86_64, Clang 19, curl development headers and libraries, Python 3, Git, dpkg-deb and curl. Check out the specified upstream source, initialize its submodule, and apply the accompanying patch. The downloaded SDK package has SHA-256 ea082b9650f3944df1e8a4737e80a35bd4f7b1e37b4b1aa49321c78d65f66812. The script validates the upstream doctest header used in test-pack builds.

```sh
git clone https://github.com/IDNI/tau-lang.git tau-tree
git -C tau-tree checkout ab7a13ed610ff6cfb8364dd2e509df74c9bdac6c
git -C tau-tree submodule update --init --recursive
git -C tau-tree apply /absolute/path/to/tau-guarded-bv.patch
curl -fsSLO https://github.com/IDNI/tau-lang/releases/download/v0.8.5/tau-sdk_0.8.5_amd64.deb
echo 'ea082b9650f3944df1e8a4737e80a35bd4f7b1e37b4b1aa49321c78d65f66812  tau-sdk_0.8.5_amd64.deb' | sha256sum -c -
dpkg-deb -x tau-sdk_0.8.5_amd64.deb sdk-package
./build.sh tau-tree sdk-package/usr/lib/tau/sdk/release patched build-dispatch
python3 replay.py build-dispatch/decision_driver
```

To run the same experiment on a separate unmodified checkout, use mode `baseline` and pass `--baseline` to replay.py. The baseline checks every semantic expectation and reports zero for the unavailable counter. Build.sh uses -O0 for compilation feasibility. Its output also reports parser and backend nanoseconds for diagnostic use; the included verdict-only receipt excludes timings.

## Complete affected upstream doctest translation unit

The supplied sdk-doctest.sh compiles all patched upstream integration test bodies with the checked solver headers and the public SDK. It stages the two original #includes in a precompiled header to bound compilation memory. The SDK predates new extern-template declarations in the devel tree. The script instantiates the public api::sat(string) member from the checked Tau source before linking. There are no omitted test assertions. The complete affected translation unit passed all 11 cases and 2,203 assertions, including all four new cases and their 2,107 assertions. Both native public string-API comparisons and the explicit option-disable and width-cap fallbacks ran. The source hashes and counts are in sdk-doctest-receipt.json. To run, use `./sdk-doctest.sh tau-tree sdk-package/usr/lib/tau/sdk/release build-doctest`.
