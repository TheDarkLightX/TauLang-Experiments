#!/bin/sh
set -eu
src=$(cd "${1:?path to patched or baseline Tau source checkout}" && pwd)
sdk=$(cd "${2:?path to the extracted public Linux x86_64 Tau 0.8.5 SDK prefix}" && pwd)
mode=${3:-patched}
work=${4:-build-dispatch}
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$work"
# Keep the generated pack definition, but let its includes see checkout sources first.
cp "$sdk/include/tau_pack.h" "$work/"
curl -fsSL https://raw.githubusercontent.com/doctest/doctest/v2.4.11/doctest/doctest.h -o "$work/doctest.h"
(cd "$work" && echo '44faa038e9c3f9728efbda143748d01124ea0a27f4bf78f35a15d8fab2e039fb  doctest.h' | sha256sum -c -)
case "$mode" in patched) set -- -DPIN_GUARD_PATH;; baseline) set -- ;; *) echo "expected patched or baseline" >&2; exit 2;; esac
"${CXX:-clang++-19}" -std=c++23 -O0 -g0 -DNDEBUG -DTAU_USE_DOCTEST \
  -DDOCTEST_CONFIG_ASSERTION_PARAMETERS_BY_VALUE -DTAU_CACHE -DTAU_PARSER_NO_TGF \
  -DTAU_USE_PORTABLE_HASH '-DTAU_PACK_BOOL_CARRIERS="bv,sbf,bool"' \
  -DTAU_CODEGEN_ARTIFACT_PREINST -DBOOST_LOG_USE_NATIVE_SYSLOG \
  -I"$work" -I"$src/tests" -I"$src/src" -I"$src/parser" \
  -I"$src/external/parser/src" -I"$sdk/include" -I"$sdk/include/tauparser" \
  -include "$src/src/extern_template_test_pack.h" "$@" "$here/decision_driver.cpp" \
  -o "$work/decision_driver" -L"$sdk/lib" -Wl,-rpath,"$sdk/lib" \
  -lTAU -ltauparser -lboost_log_setup -lboost_log -lboost_filesystem -lboost_thread \
  -lboost_chrono -lboost_atomic -lcvc5 -lgmp -lcurl -lpthread -ldl
