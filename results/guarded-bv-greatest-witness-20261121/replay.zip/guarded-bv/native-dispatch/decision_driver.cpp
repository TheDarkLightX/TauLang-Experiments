// Compile with the pinned Tau source and SDK. Read one WFF per line.
#include "tau_pack.h"
#include "boolean_algebras/bv/bv_ba.h"
#include "api.h"
#include <chrono>
#include <iostream>
#include <string>
namespace t = idni::tau_lang;
using n = t::tau_pack::node_t;
using tree_t = t::tree<n>;
int main() {
    std::string input;
    while (std::getline(std::cin, input)) {
        auto start = std::chrono::steady_clock::now();
        auto parse = tree_t::get(input, tree_t::get_options{.parse={.start=tree_t::wff}});
        if (!parse.has_value()) { std::cout << "parse-error\n"; continue; }
#ifdef PIN_GUARD_PATH
        const auto before = t::bv_guarded_witness_decisions.load();
#endif
        auto parsed = std::chrono::steady_clock::now();
        auto result = t::bv_formula_sat_status<n>(parse.value());
        auto checked = std::chrono::steady_clock::now();
        const char* verdict = (!result.has_value() || !result.value().has_value()) ? "unresolved"
            : (*result.value() == t::bv_sat_status::sat ? "sat" : (*result.value() == t::bv_sat_status::unsat ? "unsat" : "unknown"));
        std::cout << verdict << ' ';
#ifdef PIN_GUARD_PATH
        std::cout << t::bv_guarded_witness_decisions.load()-before;
#else
        std::cout << 0;
#endif
        std::cout << ' ' << std::chrono::duration_cast<std::chrono::nanoseconds>(parsed-start).count()
            << ' ' << std::chrono::duration_cast<std::chrono::nanoseconds>(checked-parsed).count() << '\n';
    }
}
