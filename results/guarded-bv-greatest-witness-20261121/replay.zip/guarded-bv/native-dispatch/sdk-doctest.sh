#!/usr/bin/env bash
# Replay the focused SDK build, including the exact source focus and omission.
set -eu
src=$(cd "${1:?patched source checkout}" && pwd)
sdk=$(cd "${2:?public release SDK prefix}" && pwd)
mkdir -p "${3:-build-doctest}"
work=$(cd "${3:-build-doctest}" && pwd)
cd "$work"
cp "$sdk/include/tau_pack.h" .
curl -fsSL https://raw.githubusercontent.com/doctest/doctest/v2.4.11/doctest/doctest.h -o doctest.h
echo '44faa038e9c3f9728efbda143748d01124ea0a27f4bf78f35a15d8fab2e039fb  doctest.h' | sha256sum -c -
target=tests/integration/test_integration-bv_quantifier_free_decision.cpp
printf '%s\n' '#include "extern_template_test_pack.h"' '#include "test_init.h"' '#include "test_tau_helpers.h"' > pch.h
python3 - "$src/$target" <<'PY'
import sys
from pathlib import Path
t=Path(sys.argv[1]).read_text()
for s in ('#include "test_init.h"\n','#include "test_tau_helpers.h"\n',
          ):
    assert t.count(s) == 1
    t=t.replace(s,'')
Path('cases.cpp').write_text(t)
PY
flags=(-std=c++23 -O0 -g0 -DNDEBUG -DTAU_USE_DOCTEST -DDOCTEST_CONFIG_ASSERTION_PARAMETERS_BY_VALUE
  -DTAU_CACHE -DTAU_PARSER_NO_TGF -DTAU_USE_PORTABLE_HASH '-DTAU_PACK_BOOL_CARRIERS="bv,sbf,bool"'
  -DTAU_CODEGEN_ARTIFACT_PREINST -DBOOST_LOG_USE_NATIVE_SYSLOG -I"$work" -I"$src/tests"
  -I"$src/src" -I"$src/parser" -I"$src/external/parser/src" -I"$sdk/include" -I"$sdk/include/tauparser")
cxx=${CXX:-clang++-19}
"$cxx" "${flags[@]}" -x c++-header pch.h -o upstream.pch
mkdir -p api
cp "$sdk/include/tau.h" api/
cp "$sdk/include/extern_template_test_pack.h" api/sdk-extern.h
cat > api/api-include.h <<'CPP'
#include "tau.h"
#include "api.h"
#include "tau_spec.h"
#include "tau_pack.h"
#include "sdk-extern.h"
CPP
cat > api/sat.cpp <<'CPP'
#include "base_ba_dispatcher.h"
#include "api.h"
#include "tau_pack.h"
namespace idni::tau_lang {
template result<bool> api<tau_pack::node_t>::sat(const std::string&);
}
CPP
# The .deb predates the additional extern template declarations for engine classes.
# Instantiate exactly the API method needed by this native test from the source tree.
"$cxx" "${flags[@]}" -include "$work/api/api-include.h" -c api/sat.cpp -o api/sat.o
"$cxx" "${flags[@]}" -include-pch upstream.pch cases.cpp api/sat.o -o qf_sdk_tests -L"$sdk/lib" -Wl,-rpath,"$sdk/lib" \
  -lTAU -ltauparser -lboost_log_setup -lboost_log -lboost_filesystem -lboost_thread -lboost_chrono \
  -lboost_atomic -lcvc5 -lgmp -lcurl -lpthread -ldl
./qf_sdk_tests --test-suite='closed bitvector mask implications'
./qf_sdk_tests
